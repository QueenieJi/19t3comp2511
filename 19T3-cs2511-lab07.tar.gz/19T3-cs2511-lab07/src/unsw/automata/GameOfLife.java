/**
 *
 */
package unsw.automata;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;

import java.util.ArrayList;

/**
 * Conway's Game of Life on a 10x10 grid.
 *
 * @author Robert Clifton-Everest
 *
 */
public class GameOfLife {
    private int length;
    private int width;
    private boolean[][] array;
    private BooleanProperty[][] feArray;

    public GameOfLife() {
        this.length = 10;
        this.width = 10;
        this.array = new boolean[this.length][this.width];
        this.feArray = new BooleanProperty[this.length][this.width];
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j ++) {
                this.array[i][j] = false;
                feArray[i][j] = new SimpleBooleanProperty(false);
                feArray[i][j].setValue(false);
            }
        }
        // TODO At the start all cells are dead
    }

    public int getLength() {
        return length;
    }

    public void setLength(int length) {
        this.length = length;
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }


    public void ensureAlive(int x, int y) {
        this.array[x][y] = true;
        this.feArray[x][y].setValue(true);
        // TODO Set the cell at (x,y) as alive
    }

    public void ensureDead(int x, int y) {
        this.array[x][y] = false;
        this.feArray[x][y].setValue(false);
        // TODO Set the cell at (x,y) as dead
    }

    public boolean isAlive(int x, int y) {
        // TODO Return true if the cell is alive
        return this.array[x][y];
    }

    public void tick() {
        boolean[][] newArray = new boolean[this.width][this.length];

        for (int x = 0; x < width; x++) {
            for (int y = 0; y < length; y++) {
                if (this.array[x][y]) {
                    if (countActiveNeighbours(x, y) > 3) {
//                        System.out.println("hello" + x + " "+y);
                        newArray[x][y] = false;
                        this.feArray[x][y].setValue(false);
                    }
                    else if (countActiveNeighbours(x, y) < 2) {
                        newArray[x][y] = false;
                        this.feArray[x][y].setValue(false);
                    }
                    else {
                        newArray[x][y] = true;
                        this.feArray[x][y].setValue(true);
                    }
                } else {
                    if (countActiveNeighbours(x, y) == 3) {
                        newArray[x][y] = true;
                        this.feArray[x][y].setValue(true);
                    }
                    else {
                        newArray[x][y] = false;
                        this.feArray[x][y].setValue(false);
                    }
                }
            }
        }

        this.array = newArray;
        // TODO Transition the game to the next generation.
    }

    public int countActiveNeighbours(int x, int y) {
        int counter = 0;
        int left = x - 1;
        int right = x + 1;
        int up = y - 1;
        int down = y + 1;
        if (left < 0) left = width - 1;
        if (right == width) right = 0;
        if (up < 0) up = length - 1;
        if (down == width) down = 0;
        if (this.array[left][up]) counter ++;
        if (this.array[left][y]) counter++;
        if (this.array[left][down]) counter ++;
        if (this.array[x][up]) counter++;
        if (this.array[x][down]) counter++;
        if (this.array[right][up]) counter++;
        if (this.array[right][y]) counter++;
        if (this.array[right][down]) counter++;

        return counter;
    }

    public BooleanProperty cellProperty(int x, int y) {
        return this.feArray[x][y];
    }
}
