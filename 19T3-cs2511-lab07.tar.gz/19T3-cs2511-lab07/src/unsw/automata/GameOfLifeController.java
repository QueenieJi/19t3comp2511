package unsw.automata;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.layout.GridPane;

import javax.swing.*;


/**
 * A JavaFX controller for the Conway's Game of Live Application.
 *
 * @author Robert Clifton-Everest
 *
 */
public class GameOfLifeController {
    private GameOfLife game;
    @FXML
    private GridPane feArray;

    @FXML
    private Button GameOfLife;

    @FXML
    private Button tick;

    public GameOfLifeController() {
        this.game = new GameOfLife();

    }

    @FXML
    void initialize() {
        for (int x = 0; x < 10; x ++) {
            for (int y = 0; y < 10; y ++) {
                CheckBox newBox = new CheckBox();
                feArray.add(newBox, x, y);
                game.cellProperty(x, y).bindBidirectional(newBox.selectedProperty());
            }
        }
    }


    @FXML
    void play(ActionEvent event) {

    }

    @FXML
    void dotick(ActionEvent event) {
        game.tick();
    }
}

