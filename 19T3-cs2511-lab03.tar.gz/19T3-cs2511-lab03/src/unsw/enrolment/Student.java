package unsw.enrolment;
import java.util.ArrayList;

public class Student {

    private String zid;
    private ArrayList<Enrolment> enrolments;

	public Student(String zid) {
        this.zid = zid;
        this.enrolments = new ArrayList<Enrolment>();
    }

    public ArrayList<Enrolment> getEnrolments() {
        return enrolments;
    }

    public void setEnrolments(Enrolment newEnrolment) {
        this.enrolments.add(newEnrolment);
    }

    public String getZID() {
		return zid;
	}

    public boolean checkEnrol(Course course, String term) {
	    if (course == null) return false;
        // check whether the course is offered in this term
        int checkOffering = 0;
        for (CourseOffering offering: course.getCourseOfferings()) {
            if (offering.getTerm().equals(term)) {
                checkOffering = 1;
                break;
            }
        }
        if (checkOffering == 0) return false;
        // check whether prerequest has been done
        // check whether the student has passed the prerequest
        for (Course pre: course.getPrereqs()) {
            int check = 0;
            for (Enrolment enrol: this.getEnrolments()) {
                if (enrol.getCourse().equals(pre) && enrol.getGrade().getMark() >= 50) {
                    check = 1;
                }
            }
            if (check == 0) return false;
        }

        return true;
    }

}
