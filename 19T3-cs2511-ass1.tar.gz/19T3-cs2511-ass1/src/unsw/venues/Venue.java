package unsw.venues;

import java.util.ArrayList;

/**
 * Venue Object
 * @author jiyuqi z5191512
 */
public class Venue {
    private String name;
    private ArrayList<Room> rooms;
    private int noRoom;

    /**
     * getters
     * @return
     */
    public String getName() {
        return name;
    }

    public ArrayList<Room> getRooms() {
        return rooms;
    }

    public int getNoRoom() {
        return noRoom;
    }

    /**
     * Simple constructor
     * @param name
     */
    public Venue (String name){
        this.name = name;
        this.rooms = new ArrayList<Room>();
        this.noRoom = this.rooms.size();
    }

    /**
     * check venue name
     * @param name
     * @return
     */
    public boolean checkName(String name) {
        if (name.equals(this.name) == true) return true;
        return false;
    }

    /**
     * add room to the venue
     * @param room
     */
    public void addRoom (Room room) {
        this.rooms.add(room);
        this.noRoom = this.rooms.size();
    }
}
