/**
 *
 */
package unsw.venues;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Scanner;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Venue Hire System for COMP2511.
 *
 * A basic prototype to serve as the "back-end" of a venue hire system. Input
 * and output is in JSON format.
 *
 * @author Robert Clifton-Everest, Queenie Ji z5191512
 *
 */
public class VenueHireSystem {

    /**
     * Constructs a venue hire system. Initially, the system contains no venues,
     * rooms, or bookings.
     */
    protected ArrayList<Room> rooms;
    protected ArrayList<Venue> venues;
    protected ArrayList<Reservation> reservations;

    public VenueHireSystem() {
        this.reservations = new ArrayList<Reservation>();
        this.rooms = new ArrayList<Room>();
        this.venues = new ArrayList<Venue>();
    }

    private void processCommand(JSONObject json) {
        switch (json.getString("command")) {

        case "room":
            String venue = json.getString("venue");
            String room = json.getString("room");
            String size = json.getString("size");
            addRoom(venue, room, size);
            break;

        case "request":
            String id = json.getString("id");
            LocalDate start = LocalDate.parse(json.getString("start"));
            LocalDate end = LocalDate.parse(json.getString("end"));
            int small = json.getInt("small");
            int medium = json.getInt("medium");
            int large = json.getInt("large");

            JSONObject result = request(id, start, end, small, medium, large);

            System.out.println(result.toString(2));
            break;

        case "cancel":
            id = json.getString("id");
            cancelBooking(id);
            break;

        case "change":
            id = json.getString("id");
            start = LocalDate.parse(json.getString("start"));
            end = LocalDate.parse(json.getString("end"));
            small = json.getInt("small");
            medium = json.getInt("medium");
            large = json.getInt("large");
            changeRequest(id, start, end, small, medium, large);
            break;

        case "list":
            venue = json.getString("venue");
            JSONArray resultArray = list(venue);
            System.out.println(resultArray.toString(2));
            // TODO Implement other commands
        }
    }

    /**
     * Function that add room to the VenueHireSystem
     * @param venue
     * @param room
     * @param size
     */
    private void addRoom(String venue, String room, String size) {
        Room newRoom = new Room(room, venue, size);
        this.rooms.add(newRoom);

        for (Venue currVenue: this.venues) {
            if (currVenue.checkName(venue)) {
                currVenue.addRoom(newRoom);
                return;
            }
        }
        // make a new venue

        Venue newVenue = new Venue(venue);
        this.venues.add(newVenue);
        newVenue.addRoom(newRoom);

    }

    /**
     * Function that make request
     * @param id
     * @param start
     * @param end
     * @param small
     * @param medium
     * @param large
     * @return
     */
    public JSONObject request(String id, LocalDate start, LocalDate end,
            int small, int medium, int large) {
        JSONObject result = new JSONObject();

        // Check whether the id is valid
        for (Reservation currReserve:this.reservations) {
            if (currReserve.checkId(id)) {
                result.put("status", "rejected");
                return result;
            }
        }

        // find a venue that has all satisfactory rooms
        // make a list of all satisfactory rooms
        Venue selectedVenue = null;
        for (Venue venue:this.venues) {

            // if the venue don't have enough rooms
            if (venue.getNoRoom() < (small + medium + large)) continue;
            // if the venue don't have enough room for each size
            if (checkVenue(venue.getRooms(), start, end, small, medium, large)) {
                selectedVenue = venue;
                break;
            }
        }
        // if no suitable venue than rejected
        if (selectedVenue == null) {
            result.put("status", "rejected");
            return result;
        }

        // make the reservation
        Reservation newReservation = new Reservation(id, start, end, small, medium, large);
        this.reservations.add(newReservation);
        result.put("status", "success");
        result.put("venue", selectedVenue.getName());

        JSONArray rooms = new JSONArray();
        for (Room room:selectedVenue.getRooms()) {

            if (checkRoom(room, start, end) == false) continue;
            if (small > 0 && room.checkSize("small")) {
                room.addReservation(newReservation);
                rooms.put(room.getName());
                small--;
                continue;
            }
            if (medium > 0 && room.checkSize("medium")) {
                room.addReservation(newReservation);
                rooms.put(room.getName());
                medium--;
                continue;
            }
            if (large > 0 && room.checkSize("large")) {
                room.addReservation(newReservation);
                rooms.put(room.getName());
                large--;
            }
        }

        result.put("rooms", rooms);
        return result;
    }

    /**
     * Help function that check whether the venue has enough rooms
     * @param roomList
     * @param start
     * @param end
     * @param small
     * @param medium
     * @param large
     * @return
     */
    private static boolean checkVenue(ArrayList<Room> roomList, LocalDate start, LocalDate end,
                                      int small, int medium, int large) {
        for (Room room:roomList) {
            if (checkRoom(room, start, end) == false) continue;
            if (small > 0 && room.checkSize("small")) {
                small--;
            }
            if (medium > 0 && room.checkSize("medium")) {
                medium--;
            }

            if (large > 0 && room.checkSize("large")) {
                large--;
            }
        }
        if (small == 0 && medium == 0 && large == 0) return true;
        else return false;
    }

    /**
     * Help function that check the room availability
     * @param room
     * @param start
     * @param end
     * @return
     */
    private static boolean checkRoom(Room room, LocalDate start, LocalDate end) {
        for (Reservation currBooking : room.getReservations()) {
            if (currBooking.checkReservation(start, end) == false) {
                return false;
            }
        }
        return true;
    }

    /**
     * Function that cancel booking
     * @param id
     */
    private void cancelBooking(String id) {
        // remove the booking from all relevant room
        for (Room room: this.rooms) {
            room.removeReservation(id);
        }
        // remove the reservation from reservation list
        Reservation cancel = null;
        for (Reservation reservation:this.reservations) {
            if (reservation.checkId(id) == true) cancel = reservation;
        }
        reservations.remove(cancel);
    }

    /**
     * Function that change request
     * @param id
     * @param start
     * @param end
     * @param small
     * @param medium
     * @param large
     */
    public void changeRequest(String id, LocalDate start, LocalDate end,
                              int small, int medium, int large) {
        // Make a copy of current requirement
        Reservation backup = null;
        for (Reservation reservation: reservations) {
            if (id.equals(reservation.getId())) {
                backup = reservation;
            }
        }
        cancelBooking(id);
        JSONObject result = request(id, start, end, small, medium, large);
        // if the request is rejected, then can't cancel booking
        String rejected = "rejected";
        if (rejected.equals(result.getString("status"))) {
           request(id, backup.getStart(), backup.getEnd(), backup.getSmall(), backup.getMedium(), backup.getLarge());
        }
        System.out.println(result.toString(2));
    }

    /**
     * Function that list all venue
     * @param venue
     * @return
     */
    public JSONArray list(String venue) {
        JSONArray result = new JSONArray();

        Venue target = null;
        for (Venue currVenue:this.venues) {
            if (currVenue.checkName(venue)) target = currVenue;
        }
        if (target == null) return result;
        for (Room room:target.getRooms()) {
            JSONObject roomInfo = new JSONObject();
            JSONArray reservations = room.listReservation();
            roomInfo.put("reservations",reservations );
            roomInfo.put("room", room.getName());
            result.put(roomInfo);
        }
        return result;
    }

    /**
     * Main function
     * @param args
     */
    public static void main(String[] args) {
        VenueHireSystem system = new VenueHireSystem();

        Scanner sc = new Scanner(System.in);

        while (sc.hasNextLine()) {
            String line = sc.nextLine();
            if (!line.trim().equals("")) {
                JSONObject command = new JSONObject(line);
                system.processCommand(command);
            }
        }
        sc.close();
    }

}
