package unsw.venues;

import java.time.LocalDate;

/**
 * Reservation Obejct
 * @author jiyuqi z5191512
 */
public class Reservation implements Comparable<Reservation>{
    private String id;
    private LocalDate start;
    private LocalDate end;
    private int small;
    private int medium;
    private int large;

    /**
     * getters
     */
    public String getId() {
        return id;
    }

    public int getSmall() {
        return small;
    }

    public int getMedium() {
        return medium;
    }

    public int getLarge() {
        return large;
    }

    public LocalDate getStart() {
        return start;
    }

    public LocalDate getEnd() { return end; }

    /**
     *  Simple constructor
     * @param id
     * @param start
     * @param end
     * @param small
     * @param medium
     * @param large
     */
    public Reservation (String id, LocalDate start, LocalDate end,
                        int small, int medium, int large){
        this.id = id;
        this.start = start;
        this.end = end;
        this.small = small;
        this.medium = medium;
        this.large = large;
    }

    /**
     * Check whether id unique
     * @param id
     * @return
     */
    public boolean checkId(String id) {
        if (id.equals(this.id) == true) return true;
        return false;
    }

    /**
     * Override method
     */
    @Override
    public int compareTo(Reservation u) {
        if (getStart() == null || u.getStart() == null) {
            return 0;
        }
        return getStart().compareTo(u.getStart());
    }

    /**
     * Check Reservation valid or not
     * @param newStart
     * @param newEnd
     * @return
     */
    public boolean checkReservation (LocalDate newStart, LocalDate newEnd) {
        // if new booking is during current reservation
        if (this.start.compareTo(newStart) <= 0 && this.end.compareTo(newEnd) >= 0) {
            return false;
        }
        // if new booking end during current reservation
        if (this.start.compareTo(newEnd) <= 0 && this.end.compareTo(newEnd) >= 0) {
            return false;
        }
        // if new booking start during current reservation
        if (this.start.compareTo(newStart) <= 0 && this.end.compareTo(newStart) >= 0) {
            return false;
        }
        // if new booking covers the current reservation
        if (this.start.compareTo(newStart) >= 0 && this.end.compareTo(newEnd) <= 0) {
            return false;
        }
        return true;
    }
}
