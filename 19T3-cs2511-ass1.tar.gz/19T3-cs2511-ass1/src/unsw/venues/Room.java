package unsw.venues;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;

/**
 * Room Obejct
 * @author jiyuqi z5191512
 */
public class Room {
    private String name;
    private String venue;
    private String size;
    private ArrayList<Reservation> reservations;

    /**
     * simple constructor
     * @param name
     * @param venue
     * @param size
     */
    public Room(String name, String venue, String size) {
        this.name = name;
        this.venue = venue;
        this.size = size;
        this.reservations = new ArrayList<Reservation>();
    }

    /**
     * getters
     * @return
     */
    public String getName() {
        return name;
    }

    public ArrayList<Reservation> getReservations() {
        return reservations;
    }

    /**
     * Remove reservation
     */
    public void removeReservation(String id) {
        Reservation cancel = null;
        for (Reservation reservation : this.reservations) {
            if (reservation.getId().equals(id)) cancel = reservation;
        }
        reservations.remove(cancel);
    }

    /**
     * Check room size
     * @param size
     * @return
     */
    public boolean checkSize(String size) {
        if (size.equals(this.size)) return true;
        return false;
    }

    /**
     * Add reservations
     * @param reservation
     */
    public void addReservation(Reservation reservation) {
        this.reservations.add(reservation);
    }

    /**
     * List the reservation for the room
     * @return
     */
    public JSONArray listReservation () {
        JSONArray reservations = new JSONArray();
        Collections.sort(this.reservations);
        for (Reservation reservation: this.reservations) {
            JSONObject details = new JSONObject();
            details.put("start", reservation.getStart());
            details.put("end", reservation.getEnd());
            details.put("id", reservation.getId());
            reservations.put(details);
        }
        return reservations;
    }
}
