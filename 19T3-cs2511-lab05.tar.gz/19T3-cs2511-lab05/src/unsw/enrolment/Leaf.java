package unsw.enrolment;

import java.io.IOException;

public class Leaf implements Component, Subject {
    private String name;
    private int mark;
    private int max;
    private Observer observer;
    private Enrolment enrolment;

    public Leaf(String name, int mark, int max, Enrolment enrolment) {
        this.name = name;
        this.mark = mark;
        this.max = max;
        this.enrolment = enrolment;
    }


    @Override
    public int calculate() {
        return this.mark;
    }

    // getters and setters below
    @Override
    public String getName() {
        return name;
    }

    // override the subject
    @Override
    public void addObserver(Observer observer) {
        this.observer = observer;
    }

    @Override
    public void removeObserver() {
        this.observer = null;
    }

    @Override
    public void notifyObservers(){
        try {
            this.observer.update(this);
            LogSystem newlog = new LogSystem(this.enrolment);
//            System.out.println(this.enrolment);
            try {
                newlog.writeLog(this);
            }
            catch (IOException o) {
            }
        }
        catch (IOException e) {

        }

    };

    public void setName(String name) {
        this.name = name;
        notifyObservers();
    }

    public int getMark() {
        return mark;
    }

    public void setMark(int mark) {
        this.mark = mark;
        notifyObservers();

    }
}
