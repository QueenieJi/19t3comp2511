package unsw.enrolment;

import java.io.FileWriter;
import java.io.*;
import java.time.LocalDate;
import java.time.LocalTime;

public class LogSystem implements Observer {
    private Enrolment enrolment;
    private String filename;
    public LogSystem(Enrolment enrolment) {
        this.enrolment = enrolment;
    }

    public void setFileName (Enrolment enrolment) {
        filename = enrolment.getCourseCode() + "-" + enrolment.getTerm() + "-" +enrolment.getZid();
//        System.out.println(filename);
    }

    public void writeLog(Subject obj) throws IOException {
        setFileName(enrolment);
        String time = LocalDate.now().toString() + "\t" + LocalTime.now().toString();
        Component change = (Component) obj;
        String msg = change.getName() + "\t" + change.getMark() + "\t" + time + "\n";
//        System.out.println(msg);
        FileWriter fileWriter = new FileWriter("./" + this.filename, true);
        fileWriter.write(msg);
        fileWriter.close();
    }
    @Override
    public void update(Subject obj) throws IOException{
        writeLog(obj);
    }

}
