package unsw.enrolment;

import java.io.IOException;
import java.util.ArrayList;

public class Average implements Component, Observer, Subject {
    private String name;
    private int mark;
    ArrayList<Component> children = new ArrayList<Component>();
    private Observer observer;
    private Enrolment enrolment;

    public Average(String name, int mark, Enrolment enrolment) {
        this.name = name;
        this.mark = mark;
        this.enrolment = enrolment;
    }

    public boolean add(Component child) {
        children.add(child);
        Subject sub = (Subject) child;
        sub.addObserver(this);
        sub.notifyObservers();
        return true;
    }
    @Override
    public int calculate(){
        int num = 0;
        int sum = 0;
        for (Component c : children) {
            if (c == null) break;
            sum += c.getMark();
            num++;
        }
        if (num > 0) {
            return sum/num;
        }
        return 0;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setMark(int mark) {
        this.mark = mark;
//        System.out.println(mark);
        if (this.observer != null) {
            notifyObservers();
            LogSystem newlog = new LogSystem(this.enrolment);
            try {
                newlog.writeLog(this);
            }
            catch (IOException o) {
            }
        }
    }

    @Override
    public String getName() {return this.name;}
    @Override
    public int getMark() {return this.mark;}

    @Override
    public void update(Subject obj){
        setMark(this.calculate());
    }

    @Override
    public void addObserver(Observer observer) {
        this.observer = observer;
    }

    @Override
    public void removeObserver() {
        this.observer = null;
    }

    @Override
    public void notifyObservers(){
        try {
            this.observer.update(this);
        }
        catch (IOException e) {

        }

    };
}
