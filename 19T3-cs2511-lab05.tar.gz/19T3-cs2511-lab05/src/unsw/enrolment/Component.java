package unsw.enrolment;

public interface Component {
    public int calculate();
    public String getName();
    public int getMark();
}
