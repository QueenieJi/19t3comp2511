package unsw.enrolment;

import java.io.IOException;

public interface Observer {
    public void update(Subject obj) throws IOException;
}
