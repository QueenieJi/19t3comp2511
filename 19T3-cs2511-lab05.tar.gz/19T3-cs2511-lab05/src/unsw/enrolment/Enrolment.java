package unsw.enrolment;

import java.awt.Component;
import java.util.ArrayList;
import java.util.List;

public class Enrolment {

    private CourseOffering offering;
    private Grade grade;
    private Student student;
    private List<Session> sessions;
    private Composite totalMark;

    public Enrolment(CourseOffering offering, Student student, Session... sessions) {
        this.offering = offering;
        this.student = student;
        this.grade = null; // Student has not completed course yet.
        student.addEnrolment(this);
        offering.addEnrolment(this);
        this.sessions = new ArrayList<>();
        for (Session session : sessions) {
            this.sessions.add(session);
        }
        this.totalMark = new Composite("total", 0, this);
    }

    public Course getCourse() {
        return offering.getCourse();
    }

    public String getCourseCode() {
        return getCourse().getCourseCode();
    }

    public String getTerm() {
        return offering.getTerm();
    }

    public Composite getTotalMark() {
        return totalMark;
    }

    public String getZid() {
        return student.getZID();
    }

    public boolean hasPassed() {
        return grade != null && grade.isPassing();
    }

//    Whole course marks can no longer be assigned this way.
//    public void assignMark(int mark) {
//        grade = new Grade(mark);
//    }

    public void assignMark(String name, int mark, int max) {
        Leaf newLeaf = new Leaf(name, mark, max, this);
        totalMark.add(newLeaf);
    }

    public void finishCourse() {
        this.grade = new Grade(totalMark.calculate());
//        System.out.println(totalMark.calculate());
    }

    public void addComposite(Composite newComposite) {
        this.totalMark.add(newComposite);
//        System.out.println(newComposite.getName());
//        System.out.println(newComposite.getObserver());
    }
}
