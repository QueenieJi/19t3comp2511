package unsw.enrolment;

import java.io.IOException;
import java.lang.management.CompilationMXBean;
import java.util.ArrayList;

public class Composite implements Component, Observer, Subject {
    private String name;
    private int mark;
    private Observer observer;
    private Enrolment enrolment;

    ArrayList<Component> children = new ArrayList<Component>();

    public Composite(String name, int mark, Enrolment enrolment) {
        super();
        this.name = name;
        this.mark = mark;
        this.enrolment = enrolment;
    }

    @Override
    public int calculate () {
        int sum = 0;
        for (Component c : children) {
            if (c == null) break;
            sum += c.getMark();
        }
        return sum;
    }

    //override observer
    @Override
    public void update(Subject obj){
        setMark(this.calculate());
    }

    public boolean add(Component child) {
        children.add(child);
        Subject sub = (Subject) child;
        sub.addObserver(this);
        sub.notifyObservers();
        return true;
    }

    public boolean remove(Component child) {
        children.remove(child);
        return true;
    }

    // getters and setters below
    @Override
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public int getMark() {
        return mark;
    }

    public void setMark(int mark) {
        this.mark = mark;
        if (this.observer != null) {
            notifyObservers();
            LogSystem newlog = new LogSystem(this.enrolment);
//            System.out.println(this.enrolment);
            try {
                newlog.writeLog(this);
            }
            catch (IOException o) {
            }
        }

    }

    @Override
    public void addObserver(Observer observer) {
        this.observer = observer;
    }

    public Observer getObserver() {
        return observer;
    }

    public Enrolment getEnrolment() {
        return enrolment;
    }

    @Override
    public void removeObserver() {
        this.observer = null;
    }

    @Override
    public void notifyObservers(){
        try {
            this.observer.update(this);
        }
        catch (IOException e) {

        }

    };
}
