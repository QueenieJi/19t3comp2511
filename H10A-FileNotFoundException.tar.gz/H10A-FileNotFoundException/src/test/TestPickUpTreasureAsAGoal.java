package test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import unsw.dungeon.model.Coord;
import unsw.dungeon.model.Direction;
import unsw.dungeon.model.Dungeon;
import unsw.dungeon.model.Player;
import unsw.dungeon.model.entity.Treasure;
import unsw.dungeon.model.goal.TreasureCollectionGoal;

public class TestPickUpTreasureAsAGoal {
	
	// Acceptance Criteria 1
	// When the player collects a treasure, 
	// the counts of treasure collected should increase.
	@Test
	public void testAC1() {
		Dungeon dungeon = new Dungeon(3, 3);
		Coord start = new Coord(1, 1);
		Player player = new Player(dungeon, start);
		dungeon.setPlayer(player);
		dungeon.addEntity(player);
		
		Coord treasureCoord = new Coord(1, 2);
		Treasure treasure = new Treasure(treasureCoord, dungeon);
		dungeon.addEntity(treasure);
		assertEquals(true, dungeon.hasTreasureLeft());
		player.move(Direction.DOWN);
		assertEquals(false, dungeon.hasTreasureLeft());
	}
	
	// Acceptance Criteria 2
	// When the player collects enough treasure, the goal is marked as completed.
	@Test
	public void testAC2() {
		Dungeon dungeon = new Dungeon(3, 3);
		Coord start = new Coord(1, 1);
		Player player = new Player(dungeon, start);
		dungeon.setPlayer(player);
		dungeon.addEntity(player);
		TreasureCollectionGoal goal = new TreasureCollectionGoal("Collect treasure",  dungeon);
		dungeon.setGoal(goal);
		
		Coord treasureCoord = new Coord(1, 2);
		Treasure treasure = new Treasure(treasureCoord, dungeon);
		dungeon.addEntity(treasure);
		assertEquals(false, goal.isFinished());
		assertEquals(true, dungeon.hasTreasureLeft());
		player.move(Direction.DOWN);
		assertEquals(false, dungeon.hasTreasureLeft());
		assertEquals(true, goal.isFinished());
	}
}
