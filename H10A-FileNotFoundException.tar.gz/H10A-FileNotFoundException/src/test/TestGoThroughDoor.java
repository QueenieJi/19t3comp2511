package test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import unsw.dungeon.model.Coord;
import unsw.dungeon.model.Dungeon;
import unsw.dungeon.model.Player;
import unsw.dungeon.model.entity.Key;
import unsw.dungeon.model.entity.Wall;
import unsw.dungeon.model.entity.door.Door;

public class TestGoThroughDoor {
	// Acceptance criteria 1
	// If the door is open, the player should be able to enter the doors.
	@Test
	public void testAC1() {
		Dungeon dungeon = new Dungeon(3, 3);
		Coord start = new Coord(1, 1);
		Player player = new Player(dungeon, start);
		Coord coord = new Coord(1,2);
		Door door = new Door(coord, dungeon, 0);
		door.changeState();
		assertEquals(true, player.isMovable(coord));
	}
	
	// Acceptance criteria 2
	// If the door is closed and the player has no keys, the player will be stuck unless he changes direction. 
	@Test
	public void testAC2() {
		Dungeon dungeon = new Dungeon(3, 3);
		Coord start = new Coord(1, 1);
		Player player = new Player(dungeon, start);
		Coord coord = new Coord(1,2);
		Door door = new Door(coord, dungeon, 0);
		dungeon.addEntity(door);
		assertEquals(false, player.isMovable(coord));
	}
	
	// Acceptance criteria 3
	// If the door is closed but the player has keys, he can go through the doors and the door is open. 
	@Test
	public void testAC3() {
		Dungeon dungeon = new Dungeon(3, 3);
		Coord start = new Coord(1, 1);
		Player player = new Player(dungeon, start);
		Coord coord = new Coord(1,2);
		Door door = new Door(coord, dungeon, 0);
		Coord wallCoord = new Coord(2, 1);
		Wall wall = new Wall(wallCoord, dungeon);
		dungeon.addEntity(wall);
		dungeon.addEntity(door);
		
		Key key = new Key(new Coord(1, 1), dungeon, 0);
		dungeon.addEntity(key);
		player.setKeyLeft(1);
		player.addInventory(key);
		player.openDoor(door);
		assertEquals(true, player.isMovable(coord));
	}
}
