package test;

import org.junit.Test;
import unsw.dungeon.model.Coord;
import unsw.dungeon.model.Direction;
import unsw.dungeon.model.Dungeon;
import unsw.dungeon.model.Player;
import unsw.dungeon.model.entity.Treasure;

import static org.junit.Assert.assertEquals;

public class TestPickUpTreasure {
    /**
     * Acceptance criteria 1
     * When the character is on the treasure, the treasure is collected by the user.
     */
    @Test
    public void testAC1() {
        Dungeon dungeon = new Dungeon(3, 3);
        Coord start = new Coord(1, 1);
        Player player = new Player(dungeon, start);
        dungeon.setPlayer(player);
        dungeon.addEntity(player);

        Coord treasureCoord = new Coord(1, 2);
        Treasure treasure = new Treasure(treasureCoord, dungeon);
        dungeon.addEntity(treasure);
        assertEquals(true, dungeon.hasTreasureLeft());
        player.move(Direction.DOWN);
        assertEquals(false, dungeon.hasTreasureLeft());
    }

}
