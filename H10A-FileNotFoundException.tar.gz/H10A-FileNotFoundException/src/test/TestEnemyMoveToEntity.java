package test;

import org.junit.Test;
import unsw.dungeon.model.Coord;
import unsw.dungeon.model.Direction;
import unsw.dungeon.model.Dungeon;
import unsw.dungeon.model.Player;
import unsw.dungeon.model.enemy.Enemy;
import unsw.dungeon.model.enemy.EnemyMoveTowards;
import unsw.dungeon.model.enemy.EnemyState;
import unsw.dungeon.model.entity.Portal;
import unsw.dungeon.model.entity.Treasure;
import unsw.dungeon.model.entity.Wall;

import static org.junit.Assert.assertEquals;

public class TestEnemyMoveToEntity {
    /**
     * Acceptance Criteria 1
     * When calculating the path, wall, closed door and boulder are count as unreachable points.
     */
    @Test
    public void testAC1() {
        /**
         * (0,0)player
         * (0,1)wall
         * (0,2)enemy
         */
        Dungeon dungeon = new Dungeon(3, 3);
        Coord playerCoord = new Coord(0, 0);
        Player player = new Player(dungeon, playerCoord);
        Coord start = new Coord(0, 2);
        Enemy enemy = new Enemy(start, dungeon);
        EnemyState state= new EnemyMoveTowards();
        enemy.setMovement(state);
        dungeon.addEntity(enemy);
        dungeon.addEntity(player);

        Wall wall = new Wall(new Coord(0, 1), dungeon);
        dungeon.addEntity(wall);

        assertEquals(Direction.RIGHT, enemy.nextDirection(playerCoord));

    }

    /**
     * Acceptance Criteria 2
     * When the enemy comes across other entities, they entities should not be picked up enemies and should not disappear.
     */
    @Test
    public void testAC2() {
        /**
         * (0,0)player
         * (0,1)treasure
         * (0,2)enemy
         */
        Dungeon dungeon = new Dungeon(3, 3);
        Coord playerCoord = new Coord(0, 0);
        Player player = new Player(dungeon, playerCoord);
        Coord start = new Coord(0, 2);
        Enemy enemy = new Enemy(start, dungeon);
        EnemyState state= new EnemyMoveTowards();
        enemy.setMovement(state);
        dungeon.addEntity(enemy);
        dungeon.addEntity(player);

        Treasure treasure = new Treasure(new Coord(0, 1), dungeon);
        dungeon.addEntity(treasure);

        assertEquals(Direction.UP, enemy.nextDirection(playerCoord));
        assertEquals(true, dungeon.hasTreasureLeft());
    }


    /**
     * Acceptance Criteria 3
     * The enemy can move over other entities. (key, treasure, portal)
     */
    @Test
    public void testAC3() {
        /**
         * (0,0)player
         * (0,1)treasure
         * (0,2)enemy
         */
        Dungeon dungeon = new Dungeon(3, 3);
        Coord playerCoord = new Coord(0, 0);
        Player player = new Player(dungeon, playerCoord);
        Coord start = new Coord(0, 2);
        Enemy enemy = new Enemy(start, dungeon);
        EnemyState state= new EnemyMoveTowards();
        enemy.setMovement(state);
        dungeon.addEntity(enemy);
        dungeon.addEntity(player);
        player.addEnemy(enemy);

        Treasure treasure = new Treasure(new Coord(0, 1), dungeon);
        dungeon.addEntity(treasure);

        assertEquals(Direction.UP, enemy.nextDirection(playerCoord));
        assertEquals(true, dungeon.hasTreasureLeft());

        player.move(Direction.RIGHT);
        Portal portal = new Portal(new Coord(0, 0), dungeon, 0);
        dungeon.addEntity(portal);
        assertEquals(Direction.RIGHT, enemy.nextDirection(new Coord(1, 0)));
    }
}

