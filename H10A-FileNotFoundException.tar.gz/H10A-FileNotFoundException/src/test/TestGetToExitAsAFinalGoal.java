package test;

import org.junit.Test;

public class TestGetToExitAsAFinalGoal {
    /**
     * Acceptance criteria 2
     * If the player finishes all other goals and then get to the exit, he wins.(
     */
    @Test
    public void testAC2() {

    }
}
