package test;

import static org.junit.Assert.assertEquals;

import junit.framework.TestCase;
import org.junit.Test;
import unsw.dungeon.model.*;
import unsw.dungeon.model.enemy.Enemy;
import unsw.dungeon.model.entity.Key;
import unsw.dungeon.model.entity.Potion;
import unsw.dungeon.model.entity.Treasure;
import unsw.dungeon.model.entity.Wall;
import unsw.dungeon.model.entity.door.Door;

public class TestPickUpInvinciblilityPotion {
    /**
     * Acceptance criteria 1
     * When the player stands on a Invincibility potion,  he will become invincible until it touched an enemy.
     */
    @Test
    public void testAC1() {
        Dungeon dungeon = new Dungeon(3, 3);
        Player player = new Player(dungeon, new Coord(0, 0));
        dungeon.setPlayer(player);
        dungeon.addEntity(player);

        Potion potion = new Potion(new Coord(1, 0), dungeon);
        dungeon.addEntity(potion);

        player.move(Direction.RIGHT);

        assertEquals(PlayerState.INVINCIABLE, player.getState());

        Enemy enemy = new Enemy(new Coord(2, 0), dungeon);
        player.addEnemy(enemy);
        dungeon.addEntity(enemy);
        player.move(Direction.RIGHT);
        assertEquals(PlayerState.NORMAL, player.getState());

    }

    /**
     * Acceptance criteria 2
     * If the player is invincible, all enemies will run away from him.
     */
    @Test
    public void testAC2() {
        /**
         * (0, 0)       (1, 0)
         * (0, 1) player(1, 1)
         * (0, 2) potion(1, 2)enemy
         */
        Dungeon dungeon = new Dungeon(3, 3);
        Coord playerCoord = new Coord(0, 1);
        Player player = new Player(dungeon, playerCoord);
        dungeon.addEntity(player);

        Coord potionCoord = new Coord(0, 2);
        Potion potion = new Potion(potionCoord, dungeon);
        dungeon.addEntity(potion);

        Enemy enemy = new Enemy(new Coord(1,2), dungeon);
        dungeon.addEntity(enemy);
        dungeon.setPlayer(player);
        player.addEnemy(enemy);
        player.move(Direction.DOWN);

        TestCase.assertEquals(PlayerState.INVINCIABLE,player.getState());
        TestCase.assertEquals(Direction.RIGHT, enemy.nextDirection(potionCoord));
    }

    /**
     * Acceptance criteria 3
     * If the player is invincible, he can walk through a wall.
     */
    @Test
    public void testAC3() {
        Dungeon dungeon = new Dungeon(3, 3);
        Wall wall = new Wall(new Coord(0, 0), dungeon);
        dungeon.addEntity(wall);

        Player player = new Player(dungeon, new Coord(1, 0));
        player.setState(PlayerState.INVINCIABLE);
        dungeon.addEntity(player);
        dungeon.setPlayer(player);

        assertEquals(true, player.isMovable(new Coord(0, 0)));
    }

    /**
     * Acceptance criteria 4
     * If the player is invincible, he still can't go through a closed door without a key
     */
    @Test
    public void testAC4() {
        Dungeon dungeon = new Dungeon(3, 3);
        Coord start = new Coord(1, 1);
        Player player = new Player(dungeon, start);
        player.setState(PlayerState.INVINCIABLE);
        Coord coord = new Coord(1,2);
        Door door = new Door(coord, dungeon, 0);
        dungeon.addEntity(door);
        assertEquals(false, player.isMovable(coord));
    }

    /**
     * Acceptance criteria 5
     * If the player is invincible, he still can pick up treasures and keys.
     */
    @Test
    public void testAC5() {
        Dungeon dungeon = new Dungeon(3, 3);
        Key key = new Key(new Coord(1, 0), dungeon, 0);
        dungeon.addEntity(key);

        Player player = new Player(dungeon, new Coord(0, 0));
        player.setState(PlayerState.INVINCIABLE);
        dungeon.addEntity(player);
        dungeon.setPlayer(player);

        player.move(Direction.RIGHT);
        TestCase.assertEquals(1, player.getKeyLeft());

        Treasure treasure = new Treasure(new Coord(1, 1), dungeon);
        dungeon.addEntity(treasure);
        player.move(Direction.DOWN);
        assertEquals(false, dungeon.hasTreasureLeft());
    }
}
