package test;

import org.junit.Test;
import unsw.dungeon.model.Coord;
import unsw.dungeon.model.Direction;
import unsw.dungeon.model.Dungeon;
import unsw.dungeon.model.Player;
import unsw.dungeon.model.enemy.Enemy;
import unsw.dungeon.model.entity.Sword;
import unsw.dungeon.model.goal.AndGoal;
import unsw.dungeon.model.goal.Goal;
import unsw.dungeon.model.goal.KillEnemyGoal;

import static junit.framework.TestCase.assertEquals;

public class TestKillAllEnemiesAsAGoal {

    /**
     * Acceptance criteria 1
     * If the player kills all the enemy, the goal is marked complete.
     */
    @Test
    public void testAC1() {
        Dungeon dungeon = new Dungeon(3, 3);
        Coord playerCoord = new Coord(0, 0);
        Player player = new Player(dungeon, playerCoord);
        dungeon.addEntity(player);
        dungeon.setPlayer(player);

        Enemy enemy1 = new Enemy(new Coord(1, 0), dungeon);
        player.addEnemy(enemy1);
        dungeon.addEntity(enemy1);

        Goal goal = new KillEnemyGoal("kill all enemies", dungeon);
        dungeon.setGoal(goal);

        // start to kill enemy
        Sword sword = new Sword(new Coord(0, 1), dungeon);
        player.addInventory(sword);

        /**
         * start to kill the enemy
         */
        dungeon.addEntity(sword);
        player.move(Direction.DOWN);
        assertEquals(5, player.getKill_times_remaining());
        player.move(Direction.RIGHT);
        player.move(Direction.UP);
//        System.out.println(player.getX());
        assertEquals(0, player.getEnemies().size());
        assertEquals(false, dungeon.hasEnemyLeft());
        assertEquals(true, goal.isFinished());
    }


    /**
     * Acceptance criteria 2
     * If the player doesn't kill all the enemy when the game ends and it is an 'and goal', the player loses the game.
     */
    @Test
    public void testAC2() {
        Dungeon dungeon = new Dungeon(3, 3);
        Coord playerCoord = new Coord(0, 0);
        Player player = new Player(dungeon, playerCoord);
        dungeon.addEntity(player);
        dungeon.setPlayer(player);

        Enemy enemy1 = new Enemy(new Coord(1, 0), dungeon);
        player.addEnemy(enemy1);
        dungeon.addEntity(enemy1);

        Goal andGoal = new AndGoal("kill all enemies and get out");
        Goal goal = new KillEnemyGoal("kill all enemies", dungeon);
        dungeon.setGoal(goal);

        // start to kill enemy
        Sword sword = new Sword(new Coord(0, 1), dungeon);
        player.addInventory(sword);

        /**
         * start to kill the enemy
         */
        dungeon.addEntity(sword);
        player.move(Direction.DOWN);
        assertEquals(5, player.getKill_times_remaining());
        player.move(Direction.RIGHT);
        player.move(Direction.UP);
        assertEquals(0, player.getEnemies().size());
        assertEquals(false, dungeon.hasEnemyLeft());
        assertEquals(true, goal.isFinished());
    }
}
