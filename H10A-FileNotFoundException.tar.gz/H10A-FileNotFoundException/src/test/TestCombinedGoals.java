package test;

import org.junit.Test;
import unsw.dungeon.model.Coord;
import unsw.dungeon.model.Direction;
import unsw.dungeon.model.Dungeon;
import unsw.dungeon.model.Player;
import unsw.dungeon.model.enemy.Enemy;
import unsw.dungeon.model.entity.Sword;
import unsw.dungeon.model.entity.Treasure;
import unsw.dungeon.model.goal.AndGoal;
import unsw.dungeon.model.goal.KillEnemyGoal;
import unsw.dungeon.model.goal.OrGoal;
import unsw.dungeon.model.goal.TreasureCollectionGoal;

import static org.junit.Assert.assertEquals;

public class TestCombinedGoals {
    /**
     * Acceptance criteria 1
     * If the goals are combined by logically AND, all the goals must be completed.
     */
    @Test
    public void testAC1() {
        /**
         * (0,0)    (1,1)           (2,0)
         * (0,1)    (1,1)player     (2,1) Sword
         * (0,2)    (1,2)Treasure   (2,2) Enemy
         */
        Dungeon dungeon = new Dungeon(3, 3);
        Coord start = new Coord(1, 1);
        Player player = new Player(dungeon, start);
        dungeon.setPlayer(player);
        dungeon.addEntity(player);
        AndGoal andGoal = new AndGoal("collect treasure and kill all enemy");
        dungeon.setGoal(andGoal);
        TreasureCollectionGoal treasureCollectionGoal = new TreasureCollectionGoal("Collect treasure",  dungeon);
        andGoal.addGoal(treasureCollectionGoal);
        KillEnemyGoal killEnemyGoal = new KillEnemyGoal("kill one enemy", dungeon);
        andGoal.addGoal(killEnemyGoal);


        Coord treasureCoord = new Coord(1, 2);
        Treasure treasure = new Treasure(treasureCoord, dungeon);
        dungeon.addEntity(treasure);

        Sword sword = new Sword(new Coord(2, 1), dungeon);
        dungeon.addEntity(sword);

        Enemy enemy = new Enemy(new Coord(2, 2), dungeon);
        dungeon.addEntity(enemy);
        player.addEnemy(enemy);


        assertEquals(false, andGoal.isFinished());
        assertEquals(true, dungeon.hasTreasureLeft());
        player.move(Direction.DOWN);
        assertEquals(false, dungeon.hasTreasureLeft());
        assertEquals(false, andGoal.isFinished());

        player.move(Direction.UP);
        player.move(Direction.RIGHT);
        player.move(Direction.DOWN);
        assertEquals(false, dungeon.hasEnemyLeft());
        assertEquals(true, andGoal.isFinished());

    }

    /**
     * Acceptance criteria 2
     * If the goals are combined by logically OR, The player can choose one of them to complete.
     */
    @Test
    public void TestAC2() {
        /**
         * (0,0)    (1,1)           (2,0)
         * (0,1)    (1,1)player     (2,1) Sword
         * (0,2)    (1,2)Treasure   (2,2) Enemy
         */
        Dungeon dungeon = new Dungeon(3, 3);
        Coord start = new Coord(1, 1);
        Player player = new Player(dungeon, start);
        dungeon.setPlayer(player);
        dungeon.addEntity(player);
        OrGoal orGoal = new OrGoal("collect treasure and kill all enemy");
        dungeon.setGoal(orGoal);
        TreasureCollectionGoal treasureCollectionGoal = new TreasureCollectionGoal("Collect treasure",  dungeon);
        orGoal.addGoal(treasureCollectionGoal);
        KillEnemyGoal killEnemyGoal = new KillEnemyGoal("kill one enemy", dungeon);
        orGoal.addGoal(killEnemyGoal);


        Coord treasureCoord = new Coord(1, 2);
        Treasure treasure = new Treasure(treasureCoord, dungeon);
        dungeon.addEntity(treasure);

        Sword sword = new Sword(new Coord(2, 1), dungeon);
        dungeon.addEntity(sword);

        Enemy enemy = new Enemy(new Coord(2, 2), dungeon);
        dungeon.addEntity(enemy);
        player.addEnemy(enemy);


        assertEquals(false, orGoal.isFinished());
        assertEquals(true, dungeon.hasTreasureLeft());
        player.move(Direction.DOWN);
        assertEquals(false, dungeon.hasTreasureLeft());
        assertEquals(true, orGoal.isFinished());

        player.move(Direction.UP);
        player.move(Direction.RIGHT);
        player.move(Direction.DOWN);
        assertEquals(false, dungeon.hasEnemyLeft());
        assertEquals(true, orGoal.isFinished());
    }
}
