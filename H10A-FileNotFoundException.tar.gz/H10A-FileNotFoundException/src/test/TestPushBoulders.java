package test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import unsw.dungeon.model.Coord;
import unsw.dungeon.model.Direction;
import unsw.dungeon.model.Dungeon;
import unsw.dungeon.model.Player;
import unsw.dungeon.model.entity.Boulder;
import unsw.dungeon.model.entity.EntityType;
import unsw.dungeon.model.entity.Switch;
import unsw.dungeon.model.entity.Wall;
import unsw.dungeon.model.entity.door.Door;

public class TestPushBoulders {
	// Acceptance criteria 1
	// When the player is face to a boulders, he can push a boulders.
	@Test
	public void testAC1() {
		Dungeon dungeon = new Dungeon(5, 3);
		Coord start = new Coord(0, 1);
		Player player = new Player(dungeon, start);
		Coord boulderCoord = new Coord(1,1);
		Boulder boulder = new Boulder(boulderCoord, dungeon);
		Coord switchCoord = new Coord(3, 1);
		Switch sw = new Switch(switchCoord, dungeon);
		dungeon.addEntity(boulder);
		dungeon.addEntity(player);
		dungeon.addEntity(sw);
		
		// test the case that successfully pushed
		player.pushBoulder(Direction.RIGHT, dungeon);
		assertEquals(EntityType.PLAYER, dungeon.getEntityType(boulderCoord));
		
	}
	// Acceptance criteria 2
	// When the player is pushing a boulder, the boulder will move in the same direction as the player
	@Test
	public void testAC2() {
		Dungeon dungeon = new Dungeon(5, 3);
		Coord start = new Coord(0, 1);
		Player player = new Player(dungeon, start);
		Coord boulderCoord = new Coord(1,1);
		Boulder boulder = new Boulder(boulderCoord, dungeon);
		Coord switchCoord = new Coord(3, 1);
		Switch sw = new Switch(switchCoord, dungeon);
		dungeon.addEntity(boulder);
		dungeon.addEntity(player);
		dungeon.addEntity(sw);
		
		// test the case that successfully pushed
		player.pushBoulder(Direction.RIGHT, dungeon);
		assertEquals(EntityType.BOULDER, dungeon.getEntityType(new Coord(2, 1)));
		
		// test the case that successfully pushed a boulder to the switch
		player.pushBoulder(Direction.RIGHT, dungeon);
		assertEquals(EntityType.PLAYER, dungeon.getEntityType(new Coord(2, 1)));
		assertEquals(EntityType.BOULDER, dungeon.getEntityType(switchCoord));
				
	}
	// Acceptance criteria 3
	// If the boulder is next to a wall, door or another boulder, it can not be pushed away.
	@Test
	public void testAC3() {
		Dungeon dungeon = new Dungeon(5, 3);
		Coord start = new Coord(0, 1);
		Player player = new Player(dungeon, start);
		Coord boulderCoord = new Coord(1,1);
		Boulder boulder = new Boulder(boulderCoord, dungeon);
		Coord switchCoord = new Coord(3, 1);
		Switch sw = new Switch(switchCoord, dungeon);
		dungeon.addEntity(boulder);
		dungeon.addEntity(player);
		dungeon.addEntity(sw);
		
		player.pushBoulder(Direction.RIGHT, dungeon);
		assertEquals(EntityType.PLAYER, dungeon.getEntityType(boulderCoord));
		assertEquals(EntityType.BOULDER, dungeon.getEntityType(new Coord(2, 1)));
		
		player.pushBoulder(Direction.RIGHT, dungeon);
		assertEquals(EntityType.PLAYER, dungeon.getEntityType(new Coord(2, 1)));
		assertEquals(EntityType.BOULDER, dungeon.getEntityType(switchCoord));
		
		// A Wall behind the boulder
		// this should do nothing
		Coord wallCoord = new Coord(4, 1);
		Wall wall = new Wall(wallCoord, dungeon);
		dungeon.addEntity(wall);
		player.pushBoulder(Direction.RIGHT, dungeon);
		assertEquals(EntityType.WALL, dungeon.getEntityType(wallCoord));
		assertEquals(EntityType.PLAYER, dungeon.getEntityType(new Coord(2, 1)));
		assertEquals(EntityType.BOULDER, dungeon.getEntityType(switchCoord));
		
		// test the case there is another boulder behind the boulder
		Boulder boulder2 = new Boulder(new Coord(3, 2), dungeon);
		Switch sw2 = new Switch(new Coord(3, 2), dungeon);
		dungeon.addEntity(boulder2);
		dungeon.addEntity(sw2);
		player.move(Direction.UP);
		player.move(Direction.RIGHT);
		player.pushBoulder(Direction.DOWN, dungeon);
		assertEquals(EntityType.BOULDER, dungeon.getEntityType(switchCoord));
		assertEquals(EntityType.PLAYER, dungeon.getEntityType(new Coord(3, 0)));
		
		// test the case there is a door behind the boulder
		Door door = new Door(new Coord(4, 2), dungeon, 0);
		dungeon.addEntity(door);
		player.move(Direction.LEFT);
		player.move(Direction.DOWN);
		player.move(Direction.DOWN);
		System.out.println("hi" + dungeon.getEntityType(new Coord(3, 2)));
		player.pushBoulder(Direction.RIGHT, dungeon);
		System.out.println("hi" + dungeon.getEntityType(new Coord(3, 2)));
		assertEquals(EntityType.BOULDER, dungeon.getEntityType(new Coord(3, 2)));
		
		assertEquals(EntityType.PLAYER, dungeon.getEntityType(new Coord(2, 2)));
		assertEquals(EntityType.CLOSEDDOOR, dungeon.getEntityType(new Coord(4, 2)));
		door.changeState();
		player.pushBoulder(Direction.RIGHT, dungeon);
		assertEquals(EntityType.BOULDER, dungeon.getEntityType(new Coord(3, 2)));
		assertEquals(EntityType.PLAYER, dungeon.getEntityType(new Coord(2, 2)));
		assertEquals(EntityType.OPENEDDOOR, dungeon.getEntityType(new Coord(4, 2)));
	}
}
