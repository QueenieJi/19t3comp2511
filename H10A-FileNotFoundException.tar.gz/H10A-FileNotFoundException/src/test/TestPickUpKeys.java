package test;

import org.junit.Test;
import unsw.dungeon.model.Coord;
import unsw.dungeon.model.Direction;
import unsw.dungeon.model.Dungeon;
import unsw.dungeon.model.Player;
import unsw.dungeon.model.entity.Key;

import static junit.framework.TestCase.assertEquals;

public class TestPickUpKeys {
    /**
     * Acceptance Criteria 1
     * When the character is on the key, the key is collected by the user.
     */
    @Test
    public void testAC1() {
        Dungeon dungeon = new Dungeon(3, 3);
        Key key = new Key(new Coord(1, 0), dungeon, 0);
        dungeon.addEntity(key);

        Player player = new Player(dungeon, new Coord(0, 0));
        dungeon.addEntity(player);
        dungeon.setPlayer(player);

        player.move(Direction.RIGHT);
        assertEquals(1, player.getKeyLeft());
    }

}
