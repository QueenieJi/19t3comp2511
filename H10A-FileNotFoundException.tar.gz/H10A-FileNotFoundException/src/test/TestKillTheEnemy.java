package test;

import org.junit.Test;
import unsw.dungeon.model.Coord;
import unsw.dungeon.model.Direction;
import unsw.dungeon.model.Dungeon;
import unsw.dungeon.model.Player;
import unsw.dungeon.model.enemy.Enemy;
import unsw.dungeon.model.entity.EntityType;
import unsw.dungeon.model.entity.Sword;
import unsw.dungeon.model.goal.Goal;
import unsw.dungeon.model.goal.KillEnemyGoal;

import static junit.framework.TestCase.assertEquals;

public class TestKillTheEnemy {
    /**
     * Acceptance criteria 1
     * If the player has a sword on hand and on the same position as an enemy, then the enemy will be killed.
     */
    @Test
    public void testAC1() {
        /**
         * (0, 0)sword  (1, 0)enemy
         * (0, 1)player
         * (0, 2)
         */
        Dungeon dungeon = new Dungeon(3, 3);
        Coord playerCoord = new Coord(0, 1);
        Player player = new Player(dungeon, playerCoord);
        dungeon.addEntity(player);
        dungeon.setPlayer(player);

        Enemy enemy1 = new Enemy(new Coord(1, 0), dungeon);
        player.addEnemy(enemy1);
        dungeon.addEntity(enemy1);

        Goal goal = new KillEnemyGoal("kill all enemies", dungeon);
        dungeon.setGoal(goal);

        /**
         * start to kill the enemy
         */
        Sword sword = new Sword(new Coord(0, 0), dungeon);
        dungeon.addEntity(sword);
        player.move(Direction.UP);
        assertEquals(5, player.getKill_times_remaining());
        player.move(Direction.RIGHT);
        assertEquals(0, player.getEnemies().size());
    }

    /**
     * Acceptance criteria 2
     * If an enemy is killed, it will disappear from the dungeon.
     */
    @Test
    public void testAC2() {
        /**
         * (0, 0)sword  (1, 0)enemy
         * (0, 1)player
         * (0, 2)
         */
        Dungeon dungeon = new Dungeon(3, 3);
        Coord playerCoord = new Coord(0, 1);
        Player player = new Player(dungeon, playerCoord);
        dungeon.addEntity(player);
        dungeon.setPlayer(player);

        Enemy enemy1 = new Enemy(new Coord(1, 0), dungeon);
        player.addEnemy(enemy1);
        dungeon.addEntity(enemy1);

        Goal goal = new KillEnemyGoal("kill all enemies", dungeon);
        dungeon.setGoal(goal);

        /**
         * start to kill the enemy
         */
        Sword sword = new Sword(new Coord(0, 0), dungeon);
        dungeon.addEntity(sword);
        player.move(Direction.UP);
        assertEquals(5, player.getKill_times_remaining());
        player.move(Direction.RIGHT);
        assertEquals(0, player.getEnemies().size());
        player.move(Direction.RIGHT);
        assertEquals(EntityType.SPACE, dungeon.getEntityType(new Coord(1, 0)));
    }

    /**
     * Acceptance criteria 3
     * If the player does not has a sword and he is on the same position as an enemy,  then the player will fail this game.
     * When the sword has killed 5 enemies, the sword will disappear.
     */
    @Test
    public void testAC3() {
        /**
         * (0, 0)sword  (1, 0)enemy
         * (0, 1)player
         * (0, 2)
         */
        Dungeon dungeon = new Dungeon(3, 3);
        Coord playerCoord = new Coord(0, 1);
        Player player = new Player(dungeon, playerCoord);
        dungeon.addEntity(player);
        dungeon.setPlayer(player);

        Enemy enemy1 = new Enemy(new Coord(1, 0), dungeon);
        player.addEnemy(enemy1);
        dungeon.addEntity(enemy1);

        Goal goal = new KillEnemyGoal("kill all enemies", dungeon);
        dungeon.setGoal(goal);

        /**
         * start to be killed by the enemy
         */
//        player.move(Direction.UP);
//        player.move(Direction.RIGHT);

    }

    /**
     * Acceptance criteria 4
     * When the sword has killed 5 enemies, the sword will disappear.
     */
    @Test
    public void testAC4() {
        /**
         * (0, 0)sword  (1, 0)enemy
         * (0, 1)player
         * (0, 2)
         */
        Dungeon dungeon = new Dungeon(10, 3);
        Coord playerCoord = new Coord(0, 1);
        Player player = new Player(dungeon, playerCoord);
        dungeon.addEntity(player);
        dungeon.setPlayer(player);

        Enemy enemy1 = new Enemy(new Coord(1, 0), dungeon);
        player.addEnemy(enemy1);
        dungeon.addEntity(enemy1);

        Enemy enemy2 = new Enemy(new Coord(2, 0), dungeon);
        player.addEnemy(enemy2);
        dungeon.addEntity(enemy2);

        Enemy enemy3 = new Enemy(new Coord(3, 0), dungeon);
        player.addEnemy(enemy3);
        dungeon.addEntity(enemy3);

        Enemy enemy4 = new Enemy(new Coord(4, 0), dungeon);
        player.addEnemy(enemy4);
        dungeon.addEntity(enemy4);

        Enemy enemy5 = new Enemy(new Coord(5, 0), dungeon);
        player.addEnemy(enemy5);
        dungeon.addEntity(enemy5);

        Goal goal = new KillEnemyGoal("kill all enemies", dungeon);
        dungeon.setGoal(goal);

        /**
         * start to be killed by the enemy
         */
        /**
         * start to kill the enemy
         */
        Sword sword = new Sword(new Coord(0, 0), dungeon);
        dungeon.addEntity(sword);
        player.move(Direction.UP);
        assertEquals(5, player.getKill_times_remaining());
        player.move(Direction.RIGHT);
        assertEquals(4, player.getKill_times_remaining());
        player.move(Direction.RIGHT);
        assertEquals(3, player.getKill_times_remaining());
        player.move(Direction.RIGHT);
        assertEquals(2, player.getKill_times_remaining());
        player.move(Direction.RIGHT);
        assertEquals(1, player.getKill_times_remaining());
        player.move(Direction.RIGHT);
        assertEquals(0, player.getKill_times_remaining());

    }

}
