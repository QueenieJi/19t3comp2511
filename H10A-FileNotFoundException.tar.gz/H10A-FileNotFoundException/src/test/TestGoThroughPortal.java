package test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import unsw.dungeon.model.Coord;
import unsw.dungeon.model.Dungeon;
import unsw.dungeon.model.entity.Portal;

public class TestGoThroughPortal {
	// Acceptance criteria 1
	// When the player stands on a Portal, the player will be transported to another portal.
	@Test
	public void testAC1() {
		Dungeon dungeon = new Dungeon(3, 3);
		Coord portalCoord1 = new Coord(1, 1);
		Portal portal1 = new Portal(portalCoord1, dungeon, 0);
		Coord portalCoord2 = new Coord(2, 2);
		Portal portal2 = new Portal(portalCoord2, dungeon, 0);
		Coord portalCoord3 = new Coord(0, 2);
		Portal portal3 = new Portal(portalCoord3, dungeon, 1);
		dungeon.addEntity(portal1);
		dungeon.addEntity(portal2);
		dungeon.addEntity(portal3);
		
		assertEquals(portalCoord2, portal1.teleportsDest(dungeon, portalCoord1));
		assertEquals(null, portal3.teleportsDest(dungeon, portalCoord3));
	}
	
	// Acceptance criteria 2
	// When the player steps back to the portal, he will be transported back to the portal
	@Test
	public void testAC2() {
		Dungeon dungeon = new Dungeon(3, 3);
		Coord portalCoord1 = new Coord(1, 1);
		Portal portal1 = new Portal(portalCoord1, dungeon, 0);
		Coord portalCoord2 = new Coord(2, 2);
		Portal portal2 = new Portal(portalCoord2, dungeon, 0);
		dungeon.addEntity(portal1);
		dungeon.addEntity(portal2);
			
		assertEquals(portalCoord2, portal1.teleportsDest(dungeon, portalCoord1));
		assertEquals(portalCoord1, portal2.teleportsDest(dungeon, portalCoord2));
	}
}
