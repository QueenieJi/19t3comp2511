package test;

import org.junit.Test;
import unsw.dungeon.model.*;
import unsw.dungeon.model.enemy.Enemy;
import unsw.dungeon.model.entity.Potion;

import static junit.framework.TestCase.assertEquals;

public class TestEnemyMoveAwayFromPlayer {
    /**
     * Acceptance criteria 1
     * When the player become invincible, all the enemies moves in opposite direction.
     */
    @Test
    public void testAC1() {
        /**
         * (0, 0)       (1, 0)
         * (0, 1) player(1, 1)
         * (0, 2) potion(1, 2)enemy
         */
        Dungeon dungeon = new Dungeon(3, 3);
        Coord playerCoord = new Coord(0, 1);
        Player player = new Player(dungeon, playerCoord);
        dungeon.addEntity(player);

        Coord potionCoord = new Coord(0, 2);
        Potion potion = new Potion(potionCoord, dungeon);
        dungeon.addEntity(potion);

        Enemy enemy = new Enemy(new Coord(1,2), dungeon);
        dungeon.addEntity(enemy);
        dungeon.setPlayer(player);
        player.addEnemy(enemy);
        player.move(Direction.DOWN);

        assertEquals(PlayerState.INVINCIABLE,player.getState());
        assertEquals(Direction.RIGHT, enemy.nextDirection(potionCoord));
    }

    /**
     * Acceptance criteria 2
     * If the player moves, enemies recalculate relative direction of player reative to them,
     * and continue to move in the opposite one.
     */
    @Test
    public void testAC2() {
        /**
         * (0, 0)       (1, 0)
         * (0, 1) player(1, 1)
         * (0, 2) potion(1, 2)enemy (2,2)
         */
        Dungeon dungeon = new Dungeon(3, 3);
        Coord playerCoord = new Coord(0, 1);
        Player player = new Player(dungeon, playerCoord);
        dungeon.addEntity(player);

        Coord potionCoord = new Coord(0, 2);
        Potion potion = new Potion(potionCoord, dungeon);
        dungeon.addEntity(potion);

        Enemy enemy = new Enemy(new Coord(1,2), dungeon);
        dungeon.addEntity(enemy);
        dungeon.setPlayer(player);
        player.addEnemy(enemy);
        player.move(Direction.DOWN);

        assertEquals(PlayerState.INVINCIABLE,player.getState());
        assertEquals(Direction.RIGHT, enemy.nextDirection(potionCoord));

        player.move(Direction.UP);
        player.move(Direction.RIGHT);
        player.move(Direction.RIGHT);
        player.move(Direction.DOWN);
        assertEquals(Direction.LEFT, enemy.nextDirection(new Coord(2, 2)));
    }


}
