package test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import unsw.dungeon.model.Coord;
import unsw.dungeon.model.Direction;
import unsw.dungeon.model.Dungeon;
import unsw.dungeon.model.Player;
import unsw.dungeon.model.enemy.Enemy;
import unsw.dungeon.model.enemy.EnemyMoveTowards;
import unsw.dungeon.model.enemy.EnemyState;

public class TestEnemyMoveToPlayer {
	
	// Acceptance criteria 1
	// When the player is moving and not invincible,
	// the enemies should find the shortest path to reach where the player current is and move to it.
	@Test
	public void testAC1() {

		Dungeon dungeon = new Dungeon(3, 3);
		Coord playerCoord = new Coord(0, 0);
		Player player = new Player(dungeon, playerCoord);
		Coord start = new Coord(0, 2);
		Enemy enemy = new Enemy(start, dungeon);
		EnemyState state= new EnemyMoveTowards();
		enemy.setMovement(state);
		dungeon.addEntity(enemy);
		dungeon.addEntity(player);
		assertEquals(Direction.UP, enemy.nextDirection(playerCoord));
		// (0, 0) (1, 0) (2, 0)
		Coord start2 = new Coord(2, 0);
		Enemy enemy2 = new Enemy(start2, dungeon);
		enemy2.setMovement(state);
		dungeon.addEntity(enemy2);
		assertEquals(Direction.LEFT, enemy2.nextDirection(playerCoord));
	}


	// Acceptance criteria 2
	// Two enemies should not stand on the same position, 
	// one of them(random picked) should be placed after the other.
	@Test
	public void testAC2() {
		Dungeon dungeon = new Dungeon(3, 3);
		Coord start = new Coord(0, 2);
		Enemy enemy = new Enemy(start, dungeon);
		EnemyState state= new EnemyMoveTowards();
		dungeon.addEntity(enemy);
		Coord start2 = new Coord(0, 1);
		Enemy enemy2 = new Enemy(start2, dungeon);
		dungeon.addEntity(enemy2);
		assertEquals(false, enemy2.isMovable(start2));
	}
	
	// Acceptance criteria 3
	// The moving path of every enemy should be recalculated after the player moves.
	@Test
	public void testAC3() {

		Dungeon dungeon = new Dungeon(3, 3);
		Coord playerCoord = new Coord(0, 0);
		Player player = new Player(dungeon, playerCoord);
		Coord start = new Coord(0, 2);
		Enemy enemy = new Enemy(start, dungeon);
		EnemyState state= new EnemyMoveTowards();
		enemy.setMovement(state);
		dungeon.addEntity(enemy);
		dungeon.addEntity(player);
		assertEquals(Direction.UP, enemy.nextDirection(playerCoord));
		
		player.move(Direction.RIGHT);
		player.move(Direction.DOWN);
		player.move(Direction.DOWN);
		assertEquals(Direction.RIGHT, enemy.nextDirection(player.getCoord()));
	}
	
	// Acceptance criteria 4
	// After recalculating the new path, all enemies should move towards the new destination. 
	@Test
	public void testAC4() {
		Dungeon dungeon = new Dungeon(3, 3);
		Coord playerCoord = new Coord(0, 0);
		Player player = new Player(dungeon, playerCoord);
		Coord start = new Coord(0, 2);
		Enemy enemy = new Enemy(start, dungeon);
		EnemyState state= new EnemyMoveTowards();
		enemy.setMovement(state);
		dungeon.addEntity(enemy);
		dungeon.addEntity(player);
		dungeon.setPlayer(player);
		assertEquals(Direction.UP, enemy.nextDirection(playerCoord));
		
		player.move(Direction.RIGHT);
		player.move(Direction.RIGHT);
		player.move(Direction.DOWN);
		player.move(Direction.DOWN);
		assertEquals(Direction.RIGHT, enemy.nextDirection(player.getCoord()));
		enemy.move(Direction.RIGHT);
		assertEquals(1, enemy.getX());
		assertEquals(2, enemy.getY());
	}
}
