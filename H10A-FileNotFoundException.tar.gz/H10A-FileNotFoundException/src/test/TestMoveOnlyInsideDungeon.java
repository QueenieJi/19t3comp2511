package test;

import org.junit.Test;

import unsw.dungeon.model.Coord;
import unsw.dungeon.model.Direction;
import unsw.dungeon.model.Dungeon;
import unsw.dungeon.model.Player;

import static org.junit.Assert.assertEquals;
public class TestMoveOnlyInsideDungeon {
	
	// Acceptance criteria 1: 
	// If the player is at the border of the dungeon and continue moving towards it, 
	// the position of the player won't be changed.
	@Test
	public void testAC1() {
		Dungeon dungeon = new Dungeon(2, 2);
		Coord coord = new Coord(0, 0);
		Player player = new Player(dungeon, coord);
		dungeon.addEntity(player);
		player.move(Direction.LEFT);
		assertEquals(coord, player.getCoord());
	}
	
	// Acceptance criteria 2:
	// If the player moves to other directions, the movement won't be affected.
	@Test
	public void testAC2() {
		Dungeon dungeon = new Dungeon(2, 2);
		Coord coord = new Coord(0, 0);
		Player player = new Player(dungeon, coord);
		dungeon.addEntity(player);
		player.move(Direction.RIGHT);
		assertEquals(1, player.getCoord().getX());
		assertEquals(0, player.getY());
	}
}
