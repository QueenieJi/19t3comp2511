package test;

import org.junit.Assert;
import org.junit.Test;
import unsw.dungeon.model.Coord;
import unsw.dungeon.model.Direction;
import unsw.dungeon.model.Dungeon;
import unsw.dungeon.model.Player;
import unsw.dungeon.model.entity.Boulder;
import unsw.dungeon.model.entity.Switch;
import unsw.dungeon.model.goal.BoulderGoal;

public class TestHavingAboulderOnEachSwitchAsAGoal {
    /**
     * Acceptance criteria 1
     * When the player pushes a boulder to a floor switch, the switch is open.
     */
    @Test
    public void testAC1() {
        Dungeon dungeon = new Dungeon(3, 3);
        Switch sw = new Switch(new Coord(0, 0), dungeon);
        dungeon.addEntity(sw);

        Boulder boulder = new Boulder(new Coord(0, 0), dungeon);
        dungeon.addEntity(boulder);

        Player player = new Player(dungeon, new Coord(1, 1));
        dungeon.addEntity(player);
        player.move(Direction.DOWN);
        Assert.assertEquals(true, sw.getActive());
    }

    /**
     * Acceptance criteria 2
     * When When all switches are open, the goal is completed.
     */
    @Test
    public void testAC2() {
        Dungeon dungeon = new Dungeon(3, 3);
        Switch sw = new Switch(new Coord(0, 0), dungeon);
        dungeon.addEntity(sw);

        Switch sw2 = new Switch(new Coord(2, 2), dungeon);
        dungeon.addEntity(sw2);

        BoulderGoal boulderGoal = new BoulderGoal("boulder goal", dungeon);
        dungeon.setGoal(boulderGoal);

        Boulder boulder = new Boulder(new Coord(0, 0), dungeon);
        dungeon.addEntity(boulder);

        Player player = new Player(dungeon, new Coord(1, 1));
        dungeon.addEntity(player);
        player.move(Direction.DOWN);
        Assert.assertEquals(true, sw.getActive());
        Assert.assertEquals(false, boulderGoal.isFinished());

        Boulder boulder1 = new Boulder(new Coord(2, 2), dungeon);
        dungeon.addEntity(boulder1);
        player.move(Direction.UP);
        Assert.assertEquals(true, boulderGoal.isFinished());

    }
}
