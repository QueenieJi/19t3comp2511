package test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import unsw.dungeon.model.Coord;
import unsw.dungeon.model.Dungeon;
import unsw.dungeon.model.Player;
import unsw.dungeon.model.enemy.Enemy;
import unsw.dungeon.model.entity.Wall;

public class TestInteractWithWalls {
	// Acceptance criteria 1
	// If a character is next to a wall, he cannot walk onto or pass the wall.
	@Test
	public void testAC1() {
		Dungeon dungeon = new Dungeon(2, 2);
		Coord start = new Coord(1, 1);
		Player player = new Player(dungeon, start);
		Coord wallCoord = new Coord(2, 1);
		Wall wall = new Wall(wallCoord, dungeon);
		dungeon.addEntity(wall);
		// call isMovable, it should do nothing
		assertEquals(false, player.isMovable(wallCoord));
	}
	
	// Acceptance criteria 1
	// If an enemy is next to a wall, he cannot walk onto or through the wall.
	@Test
	public void testAC2() {
		Dungeon dungeon = new Dungeon(2, 2);
		Coord start = new Coord(1, 1);
		Enemy enemy = new Enemy(start, dungeon);
		Coord wallCoord = new Coord(2, 1);
		Wall wall = new Wall(wallCoord, dungeon);
		dungeon.addEntity(wall);
		// call isMovable, it should do nothing
		assertEquals(false, enemy.isMovable(wallCoord));
	}
}
