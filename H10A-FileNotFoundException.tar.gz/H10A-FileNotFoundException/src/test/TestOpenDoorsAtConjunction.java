package test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import unsw.dungeon.model.Coord;
import unsw.dungeon.model.Dungeon;
import unsw.dungeon.model.Player;
import unsw.dungeon.model.entity.EntityType;
import unsw.dungeon.model.entity.Key;
import unsw.dungeon.model.entity.Wall;
import unsw.dungeon.model.entity.door.Door;

public class TestOpenDoorsAtConjunction {
	
	// Acceptance Criteria 1
	// If the player has a key in hand, he is able to open a door and pass through.
	@Test
	public void testAC1() {
		Dungeon dungeon = new Dungeon(3, 3);
		Coord start = new Coord(1, 1);
		Player player = new Player(dungeon, start);
		Coord coord = new Coord(1,2);
		Door door = new Door(coord, dungeon, 0);
		Coord wallCoord = new Coord(2, 1);
		Wall wall = new Wall(wallCoord, dungeon);
		dungeon.addEntity(wall);
		dungeon.addEntity(door);
		
		Key key = new Key(new Coord(1, 1), dungeon, 0);
		dungeon.addEntity(key);
		player.setKeyLeft(1);
		player.addInventory(key);
		player.openDoor(door);
		assertEquals(EntityType.OPENEDDOOR, door.getType());

	}
	
	// Acceptance Criteria 2
	// if the player does not have a key in hand, he can not open the door.
	@Test
	public void testAC2() {
		Dungeon dungeon = new Dungeon(3, 3);
		Coord start = new Coord(1, 1);
		Player player = new Player(dungeon, start);
		Coord coord = new Coord(1,2);
		Door door = new Door(coord, dungeon, 0);
		Coord wallCoord = new Coord(2, 1);
		Wall wall = new Wall(wallCoord, dungeon);
		dungeon.addEntity(wall);
		dungeon.addEntity(door);
		player.openDoor(door);
		// if the player does not have key in hand
		assertEquals(false, player.isMovable(coord));
		// if the player has the wrong key
		Key key = new Key(new Coord(1, 1), dungeon, 1);
		dungeon.addEntity(key);
		player.setKeyLeft(1);
		player.addInventory(key);
		player.openDoor(door);
		assertEquals(EntityType.CLOSEDDOOR, door.getType());
	}
	
	// Acceptance Criteria 3
	// When the player opens a door, the number of keys the player has should be decrement by one.
	@Test
	public void testAC3() {
		Dungeon dungeon = new Dungeon(3, 3);
		Coord start = new Coord(1, 1);
		Player player = new Player(dungeon, start);
		Coord coord = new Coord(1,2);
		Door door = new Door(coord, dungeon, 0);
		Coord wallCoord = new Coord(2, 1);
		Wall wall = new Wall(wallCoord, dungeon);
		dungeon.addEntity(wall);
		dungeon.addEntity(door);
		
		Key key = new Key(new Coord(1, 1), dungeon, 0);
		dungeon.addEntity(key);
		player.setKeyLeft(1);
		player.addInventory(key);
		player.openDoor(door);
		assertEquals(EntityType.OPENEDDOOR, door.getType());
		assertEquals(0, player.getKeyLeft());
	}
	
	// Acceptance Criteria 4
	// Each key can open a specific door and only once.
	@Test
	public void testAC4() {
		Dungeon dungeon = new Dungeon(3, 3);
		Coord start = new Coord(1, 1);
		Player player = new Player(dungeon, start);
		Coord coord = new Coord(1,2);
		Door door = new Door(coord, dungeon, 0);
		Coord wallCoord = new Coord(2, 1);
		Wall wall = new Wall(wallCoord, dungeon);
		dungeon.addEntity(wall);
		dungeon.addEntity(door);
		
		Key key = new Key(new Coord(1, 1), dungeon, 0);
		dungeon.addEntity(key);
		player.setKeyLeft(1);
		player.addInventory(key);
		player.openDoor(door);
		assertEquals(true, player.isMovable(coord));
		// add a new door with the same id, the player can not access now
		Door door2 = new Door(new Coord(0, 1), dungeon, 0);
		dungeon.addEntity(door2);
		player.openDoor(door2);
		assertEquals(EntityType.OPENEDDOOR, door.getType());
		
	}
}
