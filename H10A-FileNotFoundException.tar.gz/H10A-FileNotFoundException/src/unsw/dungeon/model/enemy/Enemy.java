package unsw.dungeon.model.enemy;

import unsw.dungeon.model.*;
import unsw.dungeon.model.entity.Entity;
import unsw.dungeon.model.entity.EntityType;

public class Enemy extends Entity implements Movable {
    /**
     * Create an entity positioned in square (x,y)
     *
     * @param cord
     * @param dungeon
     */
    private EnemyState movement;
    private Direction facingDirection;
    public Enemy(Coord coord, Dungeon dungeon) {
        super(coord, dungeon);
        this.movement = new EnemyMoveTowards();
    }

    @Override
    public void move(Direction direction) {
        if (direction == Direction.UP) y().set(getY() - 1);
        else if (direction == Direction.DOWN) y().set(getY() + 1);
        else if (direction == Direction.RIGHT) x().set(getX() + 1);
        else if (direction == Direction.LEFT) x().set(getX() - 1);
        else return;
        Coord playerCoord = super.getDungeon().getPlayer().getCoord();
        Player player = super.getDungeon().getPlayer();
        if (playerCoord.equals(super.getCoord()) && player.getState() != PlayerState.INVINCIABLE) {
            // kill player
//            System.out.println("player state" + player.getState());
            Direction playerFacing = super.getDungeon().getPlayer().getFacingDirection();
            if (facingDirection == Direction.UP && playerFacing != Direction.DOWN
              ||facingDirection == Direction.DOWN && playerFacing != Direction.UP
              ||facingDirection == Direction.LEFT && playerFacing != Direction.RIGHT
              ||facingDirection == Direction.RIGHT && playerFacing != Direction.LEFT)
                super.getDungeon().gameOver();
            // killed by player
            else if (super.getDungeon().getPlayer().getKill_times_remaining() > 0){
                super.getDungeon().pickUpEntity(playerCoord);
                player.killEnemy(this);
            }
        } else if (playerCoord.equals(super.getCoord()) && player.getState() == PlayerState.INVINCIABLE){
//            System.out.println("player state" + player.getState());
            Direction playerFacing = super.getDungeon().getPlayer().getFacingDirection();
            if (facingDirection == Direction.UP && playerFacing != Direction.DOWN
                    ||facingDirection == Direction.DOWN && playerFacing != Direction.UP
                    ||facingDirection == Direction.LEFT && playerFacing != Direction.RIGHT
                    ||facingDirection == Direction.RIGHT && playerFacing != Direction.LEFT)
                player.setState(PlayerState.NORMAL);
                // killed by player
            else if (super.getDungeon().getPlayer().getKill_times_remaining() > 0){
                super.getDungeon().pickUpEntity(playerCoord);
                player.killEnemy(this);
            }
        }
    }

    @Override
    public boolean isMovable(Coord coord) {
        return false;
    }

    @Override
    public EntityType getType() { return EntityType.ENEMY; }

    @Override
    public void walkOnto() {
        Dungeon dungeon = getDungeon();
        Player player = dungeon.getPlayer();
        if (player.getKill_times_remaining() > 0) {
            System.out.println("kill the player");
            player.killEnemy(this);
            dungeon.pickUpEntity(getCoord());
            player.x().set(getX());
            player.y().set(getY());
        } else if (player.getState() == PlayerState.INVINCIABLE) {
            player.setState(PlayerState.NORMAL);
        } else
            dungeon.gameOver();
    }

    public Direction nextDirection(Coord player) {
//        System.out.println(movement);
        Direction next =  movement.nextStep(player, getCoord(), getDungeon());

        this.facingDirection = next;
        return next;

    }

    public void setMovement(EnemyState state) { this.movement = state; }

    public void changeMovement() {
//        System.out.println(this.movement.getClass());
        this.movement.next(this);
//        System.out.println(this.movement.getClass());
    }
}
