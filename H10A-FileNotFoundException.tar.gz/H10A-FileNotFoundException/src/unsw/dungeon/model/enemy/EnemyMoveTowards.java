package unsw.dungeon.model.enemy;

import unsw.dungeon.model.Coord;
import unsw.dungeon.model.Direction;
import unsw.dungeon.model.Dungeon;
import unsw.dungeon.model.entity.EntityType;

import java.awt.font.ShapeGraphicAttribute;
import java.util.ArrayList;

public class EnemyMoveTowards implements EnemyState {
    @Override
    public void next(Enemy enemy) {
        enemy.setMovement(new EnemyMoveAway());
    }

    @Override
    public Direction nextStep(Coord playerPosition, Coord enemyPosition, Dungeon dungeon) {
        Coord[][] visited = new Coord[dungeon.getWidth()][dungeon.getHeight()];
        ArrayList<Coord> queue = new ArrayList<>();
        visited[enemyPosition.getX()][enemyPosition.getY()] = enemyPosition;
        queue.add(enemyPosition);
        boolean found = false;
        Coord start = enemyPosition;
        while (queue.size() != 0 && !found) {
            start = queue.remove(0);
            ArrayList<Coord> adjacent = new ArrayList<>();
            if (start.getX() > 0)
                adjacent.add(new Coord(start.getX() - 1, start.getY()));
            if (start.getX() < dungeon.getWidth() - 1)
                adjacent.add(new Coord(start.getX() + 1, start.getY()));
            if (start.getY() > 0)
                adjacent.add(new Coord(start.getX(), start.getY() - 1));
            if (start.getY() < dungeon.getHeight() - 1)
                adjacent.add(new Coord(start.getX(), start.getY() + 1));
            for (Coord coord : adjacent) {
                if (coord.equals(playerPosition)) {
                    found = true;
                    visited[coord.getX()][coord.getY()] = start;
                    start = coord;
                    break;
                } else if ( visited[coord.getX()][coord.getY()] == null && reachable(coord, dungeon)) {
                    visited[coord.getX()][coord.getY()] = start;
                    queue.add(coord);
                }
            }
        }

        if (!found) return Direction.FRONT;
        while (!visited[start.getX()][start.getY()].equals(enemyPosition))
            start = visited[start.getX()][start.getY()];
        if (start.getX() < enemyPosition.getX())
            return Direction.LEFT;
        else if (start.getX() > enemyPosition.getX())
            return Direction.RIGHT;
        else if (start.getY() > enemyPosition.getY())
            return Direction.DOWN;
        else if (start.getY() < enemyPosition.getY())
            return Direction.UP;
        else
            return Direction.FRONT;
    }
}
