package unsw.dungeon.model.enemy;

import unsw.dungeon.model.Coord;
import unsw.dungeon.model.Direction;
import unsw.dungeon.model.Dungeon;
import unsw.dungeon.model.PlayerState;
import unsw.dungeon.model.entity.Entity;
import unsw.dungeon.model.entity.EntityType;
import unsw.dungeon.model.entity.door.Door;

public interface EnemyState {
    void next(Enemy enemy);
    Direction nextStep(Coord playerPosition, Coord enemyPosition, Dungeon dungeon);
    default boolean reachable(Coord coord, Dungeon dungeon) {
        EntityType currType = dungeon.getEntityType(coord);

        for (Entity entity: dungeon.getEntities(coord)) {
            if (entity.getType() == EntityType.BOULDER) return false;
        }
        if (currType == EntityType.CLOSEDDOOR ) return false;
        if (currType == EntityType.WALL ) return false;
        if (currType == EntityType.ENEMY ) return false;

        return true;
    }
}
