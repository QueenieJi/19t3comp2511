package unsw.dungeon.model.enemy;

import unsw.dungeon.model.Coord;
import unsw.dungeon.model.Direction;
import unsw.dungeon.model.Dungeon;

public class EnemyMoveAway implements EnemyState {
    @Override
    public void next(Enemy enemy) {
        enemy.setMovement(new EnemyMoveTowards());
    }

    @Override
    public Direction nextStep(Coord playerPosition, Coord enemyPosition, Dungeon dungeon) {
        if (playerPosition.getX() < enemyPosition.getX()
                && enemyPosition.getX() < dungeon.getWidth()
                && reachable(new Coord(enemyPosition.getX() + 1, enemyPosition.getY()), dungeon))
            return Direction.RIGHT;
        if (playerPosition.getX() > enemyPosition.getX()
                && enemyPosition.getX() > 0
                && reachable(new Coord(enemyPosition.getX() - 1, enemyPosition.getY()), dungeon))
            return Direction.LEFT;
        if (playerPosition.getY() < enemyPosition.getY()
                && enemyPosition.getY() < dungeon.getHeight()
                && reachable(new Coord(enemyPosition.getX(), enemyPosition.getY() + 1), dungeon))
            return Direction.UP;
        if (playerPosition.getY() > enemyPosition.getY()
                && enemyPosition.getY() > 0
                && reachable(new Coord(enemyPosition.getY(), enemyPosition.getY() - 1), dungeon))
            return Direction.DOWN;
        return Direction.FRONT;
    }
}
