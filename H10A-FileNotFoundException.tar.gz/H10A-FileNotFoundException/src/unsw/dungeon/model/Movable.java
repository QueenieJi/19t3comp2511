package unsw.dungeon.model;

public interface Movable {
    void move(Direction direction);
    boolean isMovable(Coord coord);
    /**
     * decide the next position of movement to make sure the player won't move out of boundary
     * @param direction
     * @param curr
     * @param dungeon
     * @return
     */
    default Coord get_next_position(Direction direction, Coord curr, Dungeon dungeon) {
        Coord next = new Coord(curr.getX(), curr.getY());
        if (direction == Direction.UP) {
            if (curr. getY() > 0)
                next.setY(curr.getY() - 1);
        } else if (direction == Direction.DOWN) {
            if (curr.getY() < dungeon.getHeight() - 1)
                next.setY(curr.getY() + 1);
        } else if (direction == Direction.LEFT) {
            if (curr.getX() > 0)
                next.setX(curr.getX() - 1);
        } else {
            if (curr.getX() < dungeon.getWidth() - 1)
                next.setX(curr.getX() + 1);
        }
        return next;
    }
}
