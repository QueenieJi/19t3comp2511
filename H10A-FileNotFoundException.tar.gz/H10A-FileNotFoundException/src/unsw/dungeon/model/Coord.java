package unsw.dungeon.model;

/**
 * Cord class to store/ represent the cords of all entities/player on the dungeon
 */
public class Coord {
    private int x, y;
    public Coord(int x, int y) {
        this.x = x;
        this.y = y;
    }

    /**
     * getters
     * @return
     */
    public int getX() { return this.x; }

    public int getY() { return this.y; }

    /**
     * setters
     */
    public void setX(int x) { this.x = x; }

    public void setY(int y) { this.y = y; }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }

        Coord coord = (Coord)obj;
        return coord.getX() == x && coord.getY() == y;

    }
}
