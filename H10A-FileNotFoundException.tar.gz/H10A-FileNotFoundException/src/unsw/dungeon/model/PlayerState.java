package unsw.dungeon.model;

public enum PlayerState {
    NORMAL,
    INVINCIABLE
}
