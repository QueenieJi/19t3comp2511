package unsw.dungeon.model.entity;

import unsw.dungeon.model.Coord;
import unsw.dungeon.model.Dungeon;
import unsw.dungeon.model.Player;

import java.util.ArrayList;

public class Switch extends Entity{
	private boolean isActive;
	public Switch(Coord coord, Dungeon dungeon) {
		super(coord, dungeon);
		isActive = false;
	}

	@Override
	public EntityType getType() {
		return EntityType.SWITCH;
	}

	public void update() {
		ArrayList<Entity> entities = getDungeon().getEntities(getCoord());
		for (Entity e: entities) {
			if (e.getType() == EntityType.BOULDER) {
				isActive = true;
				return;
			}
		}
		isActive = false;
	}

	public boolean getActive() { return this.isActive; }


}
