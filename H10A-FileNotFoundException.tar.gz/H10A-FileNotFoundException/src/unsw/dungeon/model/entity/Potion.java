package unsw.dungeon.model.entity;

import unsw.dungeon.model.Coord;
import unsw.dungeon.model.Dungeon;
import unsw.dungeon.model.Player;
import unsw.dungeon.model.PlayerState;

public class Potion extends Entity{
    /**
     * Create an entity positioned in square (x,y)
     *
     * @param coord
     * @param dungeon
     */
    public Potion(Coord coord, Dungeon dungeon) {
        super(coord, dungeon);
    }

    @Override
    public EntityType getType() {
        return EntityType.POTION;
    }

    @Override
    public void walkOnto() {
        Dungeon dungeon = getDungeon();
        Player player = dungeon.getPlayer();
        player.setState(PlayerState.INVINCIABLE);
        dungeon.pickUpEntity(this.getCoord());
        player.notifyEnemies();
        player.x().set(getX());
        player.y().set(getY());
    }

}
