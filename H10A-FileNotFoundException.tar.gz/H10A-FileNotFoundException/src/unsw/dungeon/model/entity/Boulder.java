package unsw.dungeon.model.entity;
import unsw.dungeon.model.Coord;
import unsw.dungeon.model.Direction;
import unsw.dungeon.model.Dungeon;
import unsw.dungeon.model.Movable;

public class Boulder extends Entity implements Movable {
	private Dungeon dungeon;

	public Boulder(Coord coord, Dungeon dungeon) {
		super(coord, dungeon);
		this.dungeon = dungeon;
	}

	
	@Override
	public EntityType getType() {
		return EntityType.BOULDER;
	}


	@Override
	public void move(Direction direction) {
		Coord nextCoord = this.get_next_position(direction, new Coord(getX(), getY()), dungeon);
        if (isMovable(nextCoord)) {
            y().set(nextCoord.getY());
            x().set(nextCoord.getX());

        }
	}

	/**
	 * Check whether the boulder is able to move to the dest coord
	 * @param coord
	 * @return
	 */
	@Override
	public boolean isMovable(Coord coord) {
		EntityType currType = dungeon.getEntityType(coord);
		if (currType == EntityType.WALL) {
			System.out.println("because there is a wall!");
			return false;
		}
		if (checkBoulder(this.dungeon, coord)) {
			System.out.println("because there is a boulder!");
			return false;
		}
		if (currType == EntityType.CLOSEDDOOR) {
			System.out.println("because there is a door!");
			return false;
		}
		if (currType == EntityType.OPENEDDOOR) return false;
		return true;
	}

	/**
	 * check whether the coord has a boulder
	 * @param dungeon
	 * @param coord
	 * @return
	 */
	private boolean checkBoulder(Dungeon dungeon, Coord coord) {
		for (Entity e: dungeon.getEntities(coord)) {
			if (e.getType() == EntityType.BOULDER) return true;
		}
		return false;
	}
}
