package unsw.dungeon.model.entity.door;

import unsw.dungeon.model.entity.EntityType;

public class ClosedDoorState implements DoorState{

	@Override
	public void current(Door door) {
		door.setState(this);
		door.setImage("/closed_door.png");
	}

	@Override
	public void next(Door door) {
		door.setState(new OpenDoorState());
		door.setImage("/open_door.png");
	}

	@Override
	public boolean isOpen() {
		return false;
	}

	@Override
	public EntityType getType() {
		return EntityType.CLOSEDDOOR;
	}

}
