package unsw.dungeon.model.entity.door;

import unsw.dungeon.model.entity.EntityType;

public class OpenDoorState implements DoorState{

	@Override
	public void current(Door door) {
		door.setState(this);
		door.setImage("/open_door.png");
	}

	@Override
	public void next(Door door) {
		door.setState(new ClosedDoorState());
		door.setImage("/closed_door.png");
	}

	@Override
	public boolean isOpen() {
		return true;
	}

	@Override
	public EntityType getType() {
		return EntityType.OPENEDDOOR;
	}

}
