package unsw.dungeon.model.entity.door;

import unsw.dungeon.model.Coord;
import unsw.dungeon.model.Dungeon;
import unsw.dungeon.model.entity.Entity;
import unsw.dungeon.model.entity.EntityType;

public class Door extends Entity{
	
	private DoorState state;
	private String image;
	private int id;

	public Door(Coord coord, Dungeon dungeon, int id) {
		super(coord, dungeon);
		DoorState state = new ClosedDoorState();
		this.state = state;
		this.image = "/closed_door.png";
		this.id = id;
	}
	// getters and setters
	public DoorState getState() {
		return this.state;
	}

	public int getId() {
		return id;
	}

	public boolean isOpen() {
		return this.state.isOpen();
	}
	public void setState(DoorState state) {
		this.state = state;
	}

	public void setImage(String image) {
		this.image = image;
	}
	
	
	public void changeState() {
		System.out.println(this.state.getClass());
		System.out.println(this.getType());
		this.state.next(this);
		System.out.println(this.state.getClass());
		System.out.println(this.getType());
	}

	@Override
	public EntityType getType() {
		return state.getType();
	}

	@Override
	public void walkOnto() {
		if (isOpen()) {
			getDungeon().getPlayer().y().set(getY());
			getDungeon().getPlayer().x().set(getX());
		}

	}

}
