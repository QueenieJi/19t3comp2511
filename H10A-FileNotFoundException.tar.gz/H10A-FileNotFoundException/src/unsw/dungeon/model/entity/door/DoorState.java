package unsw.dungeon.model.entity.door;

import unsw.dungeon.model.entity.EntityType;

public interface DoorState {
	// current state
	public void current(Door door);
	// next state
	public void next(Door dnoor);
	// state name
	public boolean isOpen();

	EntityType getType();
}
