package unsw.dungeon.model.entity;

public enum EntityType {
    WALL,
    EXIT,
    PLAYER,
    KEY,
    TREASURE,
    BOULDER,
    SPACE,
    SWITCH,
    OPENEDDOOR,
    CLOSEDDOOR,
    POTION,
    PORTAL,
    TELEPORT,
    ENEMY,
    SWORD
}
