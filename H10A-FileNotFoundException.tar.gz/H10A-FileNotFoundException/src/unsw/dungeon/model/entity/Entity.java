package unsw.dungeon.model.entity;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import unsw.dungeon.model.Coord;
import unsw.dungeon.model.Dungeon;
import unsw.dungeon.model.Player;

/**
 * An entity in the dungeon.
 * @author Robert Clifton-Everest
 *
 */
public abstract class Entity {

    // IntegerProperty is used so that changes to the entities position can be
    // externally observed.
    private IntegerProperty x, y;
    private Dungeon dungeon;

    /**
     * Create an entity positioned in square (x,y)
     * @param coord
     * @param dungeon
     */
    public Entity(Coord coord, Dungeon dungeon) {
        this.x = new SimpleIntegerProperty(coord.getX());
        this.y = new SimpleIntegerProperty(coord.getY());
        this.dungeon = dungeon;
    }

    public IntegerProperty x() {
        return x;
    }

    public IntegerProperty y() {
        return y;
    }

    public int getY() {
        return y().get();
    }

    public int getX() {
        return x().get();
    }

    public Coord getCoord() { return new Coord(x().get(), y().get()); }
    public Dungeon getDungeon() { return this.dungeon; }

    public abstract EntityType getType();

    public void walkOnto() {
        Dungeon dungeon = getDungeon();
        Player player = dungeon.getPlayer();
        player.addInventory(this);
        player.x().set(getX());
        player.y().set(getY());
    }
}
