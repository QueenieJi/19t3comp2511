package unsw.dungeon.model.entity;

import unsw.dungeon.model.Coord;
import unsw.dungeon.model.Dungeon;

public class Exit extends Entity {

    public Exit(Coord coord, Dungeon dungeon) {
		super(coord, dungeon);
	}

    @Override
    public EntityType getType() {
        return EntityType.EXIT;
    }

    @Override
    public void walkOnto() {
        getDungeon().gameOver();
    }

}