package unsw.dungeon.model.entity;

import unsw.dungeon.model.Coord;
import unsw.dungeon.model.Dungeon;

public class Wall extends Entity {

    public Wall(Coord coord, Dungeon dungeon) {
        super(coord, dungeon);
    }

    @Override
    public EntityType getType() {
        return EntityType.WALL;
    }


}
