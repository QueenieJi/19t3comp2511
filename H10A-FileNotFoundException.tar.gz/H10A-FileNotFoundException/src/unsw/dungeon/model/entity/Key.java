package unsw.dungeon.model.entity;

import unsw.dungeon.model.Coord;
import unsw.dungeon.model.Dungeon;
import unsw.dungeon.model.Player;


public class Key extends Entity {

	private int id;

	public Key(Coord coord, Dungeon dungeon, int id) {
		super(coord, dungeon);
		this.id = id;
	}

	@Override
	public EntityType getType() {
		return EntityType.KEY;
	}

	@Override
	public void walkOnto() {
		Dungeon dungeon = getDungeon();
		Player player = dungeon.getPlayer();
		player.pickUpKeys(this);
		dungeon.pickUpEntity(this.getCoord());

		player.y().set(getY());
		player.x().set(getX());
	}

	public int getId() {
		return id;
	}
}
