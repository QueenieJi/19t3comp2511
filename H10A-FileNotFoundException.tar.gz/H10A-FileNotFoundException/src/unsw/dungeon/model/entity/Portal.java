package unsw.dungeon.model.entity;

import unsw.dungeon.model.Coord;
import unsw.dungeon.model.Dungeon;
import unsw.dungeon.model.Player;

public class Portal extends Entity {
	private int id;
    /**
     * Create an entity positioned in square (x,y)
     *
     * @param coord
     * @param dungeon
     */
    
    public Portal(Coord coord, Dungeon dungeon, int id) {
        super(coord, dungeon);
        this.id = id;
    }
    
    public int getId() {
    	return this.id;
    }

    @Override
    public EntityType getType() {
        return EntityType.PORTAL;
    }

    @Override
    public void walkOnto() {
        Dungeon dungeon = getDungeon();
        Player player = dungeon.getPlayer();
        Coord nextCoord = this.getCoord();
        nextCoord = ((Portal) (dungeon.getEntity(nextCoord))).teleportsDest(dungeon, nextCoord);
        if (nextCoord != null) {
            y().set(nextCoord.getY());
            x().set(nextCoord.getX());
        }
    }

    public Coord teleportsDest(Dungeon dungeon, Coord currCoord) {
    	Coord newCoord = null;
    	if (dungeon.getEntityType(currCoord) != EntityType.PORTAL) return null;
    	Portal curr = (Portal) dungeon.getEntity(currCoord);
    	for (Entity e: dungeon.getEntities()) {
//    		System.out.println(e.getClass());
    		if (e.getType() == EntityType.PORTAL && ((Portal)e).getId() == curr.getId() && (e.getX() != currCoord.getX() || e.getY() != currCoord.getY())) {
    			newCoord = e.getCoord();
    			
//    			System.out.println(currCoord.getX());
    		}
    		
    	}
    	
    	return newCoord;
    }
    
    

}
