package unsw.dungeon.model.entity;

import unsw.dungeon.model.Coord;
import unsw.dungeon.model.Dungeon;
import unsw.dungeon.model.Player;


public class Treasure extends Entity {

	public Treasure(Coord coord, Dungeon dungeon) {
		super(coord, dungeon);
	}

	@Override
	public EntityType getType() {
		return EntityType.TREASURE;
	}

	@Override
	public void walkOnto() {
		Dungeon dungeon = getDungeon();
		Player player = dungeon.getPlayer();
		player.addInventory(this);
		dungeon.pickUpEntity(this.getCoord());
		player.x().set(getX());
		player.y().set(getY());
	}

}
