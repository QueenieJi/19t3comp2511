/**
 *
 */
package unsw.dungeon.model;

import java.util.ArrayList;
import java.util.List;

import unsw.dungeon.model.enemy.Enemy;
import unsw.dungeon.model.entity.Boulder;
import unsw.dungeon.model.entity.Entity;
import unsw.dungeon.model.entity.EntityType;
import unsw.dungeon.model.entity.Switch;
import unsw.dungeon.model.goal.Goal;

/**
 * A dungeon in the interactive dungeon player.
 *
 * A dungeon can contain many entities, each occupy a square. More than one
 * entity can occupy the same square.
 *
 * @author Robert Clifton-Everest
 *
 */
public class Dungeon {

    private int width, height;
    private List<Entity> entities;
    private Player player;
    private Enemy enemy;
    Goal goal;

    public Dungeon(int width, int height) {
        this.width = width;
        this.height = height;
        this.entities = new ArrayList<>();
        this.player = null;
        this.enemy = null;
    }

    public int getWidth() {
        return width;
    }

    public List<Entity> getEntities() {
        return entities;
    }

    public int getHeight() {
        return height;
    }

    public Player getPlayer() {
        return player;
    }

    public Enemy getEnemy() {
        return enemy;
    }

    public void setEnemy(Enemy enemy) {
        this.enemy = enemy;
    }

    public void setPlayer(Player player) {
        this.player = player;
    }

    public void setGoal(Goal goal) { this.goal = goal; }

    public void addEntity(Entity entity) {
        entities.add(entity);
    }

    public void updateSwitch() {
        for (Entity e: entities)
            if (e.getType() == EntityType.SWITCH)
                ((Switch)e).update();
    }

    public boolean allBoulderActive() {
        for (Entity e: entities)
            if (e.getType() == EntityType.SWITCH && !((Switch)e).getActive()) return false;
         return true;
    }
    public boolean hasEnemyLeft() {
        int sum = 0;

        for (Entity e: entities)
            if (e.getType() == EntityType.ENEMY) sum++;
        return sum > 0;

    }
    /**
     * check whether there are some treasure left on the dungeon
     * no treasure indicates the player has collected all treasures
     * @return
     */
    public boolean hasTreasureLeft() {
        int sum = 0;
        for (Entity e: entities)
            if (e.getType() == EntityType.TREASURE) sum++;
        return sum > 0;
    }
    /**
     * check whether the player current position is at the exit
     * if it is, the goal to exit is completed
     */
    public boolean playerAtExit() {
        Coord exitCoord = new Coord(-1, -1);
        for (Entity e: entities)
            if (e.getType() == EntityType.EXIT)
                exitCoord = e.getCoord();

        return player.getCoord().equals(exitCoord);
    }

    /**
     * check whether the player can step on to the pixel of grid
     * @param coord
     * @return
     */
    public EntityType getEntityType(Coord coord) {
        for (Entity e: entities)
            if (e.getCoord().equals(coord)) return e.getType();
        return EntityType.SPACE;
    }

    /**
     * return a list of entities on one coord: e.g. a switch and a boulder
     * @param coord
     * @return
     */
    public ArrayList<Entity> getEntities(Coord coord) {
    	ArrayList<Entity> newList = new ArrayList<Entity>();
    	for (Entity e: entities)
            if (e.getCoord().equals(coord)) newList.add(e);
    	return newList;
    }
    
    /**
     * get the entity of a given cord
     * @param coord
     * @return
     */
    public Entity getEntity(Coord coord) {
        for (Entity e: entities)
            if (e.getCoord().equals(coord)) return e;
        return null;
    }
    
    public void gameOver() {
        if (this.goal != null && this.goal.isFinished())
            System.out.println("GameOver, YouWin!");
        else
            System.out.println("GameOver, YouLose!");
        System.exit(0);
    }

    public void pickUpEntity(Coord coord) {
        Entity entity = null;
        for (Entity e: entities)
            if (e.getCoord().equals(coord) && e.getType() != EntityType.PLAYER) entity = e;
        if (entity != null) entities.remove(entity);

    }
}
