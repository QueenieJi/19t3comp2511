package unsw.dungeon.model.goal;

import unsw.dungeon.model.Dungeon;

public class ExitGoal extends Goal {
    private Dungeon dungeon;

    public ExitGoal(String description, Dungeon dungeon) {
        super(description);
        this.dungeon = dungeon;
    }

    @Override
    public void update() {
        setFinished(dungeon.playerAtExit());
    }

    @Override
    public boolean isLeafGoal() {
        return true;
    }
}
