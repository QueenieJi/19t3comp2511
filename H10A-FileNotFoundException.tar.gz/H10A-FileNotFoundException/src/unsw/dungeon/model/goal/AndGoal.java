package unsw.dungeon.model.goal;

import java.util.ArrayList;

public class AndGoal extends Goal {
    private ArrayList<Goal> subGoals;

    public AndGoal(String description) {
        super(description);
        this.subGoals = new ArrayList<>();
    }


    public void addGoal(Goal goal) {
        this.subGoals.add(goal);
        this.update();
    }

    @Override
    public void update() {
        boolean allDone = true;
        for (Goal g: subGoals) {
            g.update();
            if (!g.isFinished()) allDone = false;
        }
        super.setFinished(allDone);
    }

    @Override
    public boolean isLeafGoal() {
        return false;
    }

}
