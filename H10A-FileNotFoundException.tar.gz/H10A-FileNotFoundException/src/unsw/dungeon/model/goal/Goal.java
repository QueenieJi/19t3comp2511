package unsw.dungeon.model.goal;


public abstract class Goal {
    private String description;
    private boolean finished;

    public Goal(String description) {
        this.description = description;
        this.finished = false;
    }
    public boolean isFinished() {
        this.update();
        return finished;
    }

    public String displayGoal() {
        return description;
    }

    public void update() {

    }

    public void setFinished(boolean finished) { this.finished = finished;}

    public boolean isLeafGoal() {
        return false;
    }
}
