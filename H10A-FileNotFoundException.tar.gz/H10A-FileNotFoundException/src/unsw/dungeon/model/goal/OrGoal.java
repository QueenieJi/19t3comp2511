package unsw.dungeon.model.goal;

import java.util.ArrayList;

public class OrGoal extends Goal {
    private ArrayList<Goal> subGoals;
    public OrGoal(String description) {
        super(description);
        this.subGoals = new ArrayList<>();
    }

    public void addGoal(Goal goal) { this.subGoals.add(goal); }

    /**
     * update the status of the goal
     */
    @Override
    public void update() {
        boolean allDone = false;
        for (Goal g: subGoals) {
            g.update();
            if (g.isFinished()) allDone = true;
        }
       setFinished(allDone);
    }

    @Override
    public boolean isLeafGoal() {
        return false;
    }
}
