package unsw.dungeon.model;

import unsw.dungeon.model.enemy.Enemy;
import unsw.dungeon.model.entity.Boulder;
import unsw.dungeon.model.entity.Entity;
import unsw.dungeon.model.entity.EntityType;
import unsw.dungeon.model.entity.Key;
import unsw.dungeon.model.entity.Portal;
import unsw.dungeon.model.entity.Treasure;
import unsw.dungeon.model.entity.door.Door;

import java.util.ArrayList;


/**
 * The player entity
 * @author Robert Clifton-Everest
 *
 */

public class Player extends Entity implements Movable {


    private Dungeon dungeon;

    private ArrayList<Entity> inventory;

    // number of current available keys
    private int keyLeft;
    private PlayerState state;
    private ArrayList<Enemy> enemies;
    private int kill_times_remaining;
    private Direction facingDirection;

    public void addEnemy(Enemy e) {
        this.enemies.add(e);
    }

    public ArrayList<Entity> getInventory() {
        return inventory;
    }

    public void addInventory(Entity e) {
        this.inventory.add(e);
    }

    public int getKeyLeft() {
        return keyLeft;
    }

    public void setKeyLeft(int keyLeft) {
        this.keyLeft = keyLeft;
    }

    public Direction getFacingDirection() { return this.facingDirection; }

    public boolean hasSword() { return this.kill_times_remaining > 0; }

    public PlayerState getState() { return this.state; }

    public void setState(PlayerState state) { this.state = state; }

    /**
     * Create a player positioned in square (x,y)
     * @param dungeon
     * @param coord
     */
    public Player(Dungeon dungeon, Coord coord) {
        super(coord, dungeon);
        this.dungeon = dungeon;
        this.enemies = new ArrayList<>();
        this.inventory = new ArrayList<>();
        this.keyLeft = 0;
        this.state = PlayerState.NORMAL;
        this.kill_times_remaining = 0;
        this.facingDirection = Direction.FRONT;
    }

    /**
     * handle player move
     * @param direction
     */
    @Override
    public void move(Direction direction) {
        Coord nextCoord = this.get_next_position(direction, new Coord(getX(), getY()), dungeon);
         if (isMovable(nextCoord)) {
            this.movement(nextCoord);
            dungeon.updateSwitch();
        }

    }

    public void notifyEnemies() {
        for (Enemy e: enemies) {
            e.changeMovement();
        }
    }

    public ArrayList<Enemy> getEnemies() {
        return enemies;
    }

    /**
     * if the player is able to move to the next position, he may be able to pickup a treasure, key
     * or open/not open a door
     * push boulder
     * @param coord
     */
    private void movement(Coord coord) {
        EntityType type = dungeon.getEntityType(coord);
        Entity e = dungeon.getEntity(coord);
        if (type == EntityType.SPACE) {
            x().set(coord.getX());
            y().set(coord.getY());
            return;
        }
        System.out.println(type);
        e.walkOnto();
    }

    public void pickUpSword(Entity entity) {
        this.kill_times_remaining += 5;
    }

    public void killEnemy(Enemy enemy) {
        this.enemies.remove(enemy);
        this.kill_times_remaining--;
    }

    public int getKill_times_remaining() {
        return kill_times_remaining;
    }

    /**
     *
     * @param direction
     * @param dungeon
     */
    public void pushBoulder(Direction direction, Dungeon dungeon) {
    	Coord nextPlayerCoord = this.get_next_position(direction, new Coord(getX(), getY()), dungeon);
    	Boulder boulder = null;
    	for (Entity entity: dungeon.getEntities(nextPlayerCoord)) {
    		if (entity.getType() == EntityType.BOULDER) {
        		boulder = (Boulder) entity;
        	}
    	}
    	
    	if (boulder == null) return;
    	Coord nextBoulderCoord = boulder.get_next_position(direction, nextPlayerCoord, dungeon);
        if (boulder.isMovable(nextBoulderCoord)) {
        	boulder.move(direction);
        	this.move(direction);
        }
    }

    /**
     * check whether the player can move to dest position or not
     * @param coord
     * @return
     */
    @Override
    public boolean isMovable(Coord coord) {
        EntityType currType = dungeon.getEntityType(coord);
        Entity e = dungeon.getEntity(coord);
        for (Entity entity: dungeon.getEntities(coord)) {
        	if (entity.getType() == EntityType.BOULDER) return false;
        }
        if (currType == EntityType.CLOSEDDOOR && keyLeft == 0) return false;
        else if (currType == EntityType.WALL && this.state != PlayerState.INVINCIABLE) return false;
        else if (currType == EntityType.CLOSEDDOOR) {
            this.openDoor((Door) e);
            currType = dungeon.getEntityType(coord);
            if (currType == EntityType.CLOSEDDOOR) {
            	return false;
            	
            }
        }
       
        return true;
    }


    @Override
    public EntityType getType() {
        return EntityType.PLAYER;
    }

    @Override
    public void walkOnto() {

    }

    public void pickUpKeys(Key key) {
        this.keyLeft++;
        this.inventory.add(key);
    }
    /**
     * open the door with key in hand
     * @param door
     * @return
     */
    public void openDoor(Door door) {
    	if (checkKey(door)) door.changeState();
    	this.keyLeft --;
    }

    /**
     * Check whether the player has a right key
     * @param door
     * @return
     */
    private boolean checkKey(Door door) {
        for (Entity key : this.inventory) {
            if (key.getType() == EntityType.KEY && !door.isOpen()) {
      
                if (((Key) key).getId() == door.getId()) {
                    return true;
                }
            }
        }
        return false;
    }
}
