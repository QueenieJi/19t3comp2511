package unsw.dungeon.controller;

import java.util.ArrayList;

import java.util.List;

import javafx.animation.*;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.GridPane;
import javafx.util.Duration;

import unsw.dungeon.model.*;
import unsw.dungeon.model.enemy.Enemy;

/**
 * A JavaFX controller for the dungeon.
 * @author Robert Clifton-Everest
 *
 */
public class DungeonController {

    @FXML
    private GridPane squares;

    private List<ImageView> initialEntities;

    private Player player;

    private Enemy enemy;

    private Dungeon dungeon;

    public DungeonController(Dungeon dungeon, List<ImageView> initialEntities) {
        this.dungeon = dungeon;
        this.player = dungeon.getPlayer();
        this.enemy = dungeon.getEnemy();
        this.initialEntities = new ArrayList<>(initialEntities);
    }

    @FXML
    public void initialize() {
        Image ground = new Image("/dirt_0_new.png");

        // Add the ground first so it is below all other entities
        for (int x = 0; x < dungeon.getWidth(); x++) {
            for (int y = 0; y < dungeon.getHeight(); y++) {
                squares.add(new ImageView(ground), x, y);
            }
        }

        for (ImageView entity : initialEntities)
            squares.getChildren().add(entity);

        Timeline timeline = new Timeline();
        timeline.setCycleCount(Animation.INDEFINITE);
        timeline.setAutoReverse(true);
        timeline.getKeyFrames().add(new KeyFrame(Duration.millis(500),
                new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event) {
//                        System.out.println(enemy);
                        enemyMove();
                    }
                }));
        timeline.play();
    }

    @FXML
    public void handleKeyPress(KeyEvent event) {
        switch (event.getCode()) {
        case UP:
            player.move(Direction.UP);
            player.pushBoulder(Direction.UP, this.dungeon);
            break;
        case DOWN:
            player.move(Direction.DOWN);
            player.pushBoulder(Direction.DOWN, this.dungeon);
            break;
        case LEFT:
            player.move(Direction.LEFT);
            player.pushBoulder(Direction.LEFT, this.dungeon);
            break;
        case RIGHT:
            player.move(Direction.RIGHT);
            player.pushBoulder(Direction.RIGHT, this.dungeon);
            break;
        default:
            break;
        }
    }

    @FXML
    public void enemyMove() {
//        System.out.println(enemy.nextDirection(this.player.getCoord()));
        enemy.move(enemy.nextDirection(this.player.getCoord()));
    }
}

