package unsw.dungeon.controller;

public enum  GameState {
    EASY,
    MEDIUM,
    HARD
}
