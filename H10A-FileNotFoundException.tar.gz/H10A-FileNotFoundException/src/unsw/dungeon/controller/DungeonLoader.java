package unsw.dungeon.controller;

import java.io.FileNotFoundException;
import unsw.dungeon.model.*;
import unsw.dungeon.model.enemy.Enemy;
import unsw.dungeon.model.entity.*;
import unsw.dungeon.model.entity.door.Door;

import java.io.FileReader;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;
import unsw.dungeon.model.goal.*;

/**
 * Loads a dungeon from a .json file.
 *
 * By extending this class, a subclass can hook into entity creation. This is
 * useful for creating UI elements with corresponding entities.
 *
 * @author Robert Clifton-Everest
 *
 */
public abstract class DungeonLoader {

    private JSONObject json;

    public DungeonLoader(String filename) throws FileNotFoundException {
        json = new JSONObject(new JSONTokener(new FileReader("dungeons/" + filename)));
    }

    /**
     * Parses the JSON to create a dungeon.
     * @return
     */
    public Dungeon load() {
        int width = json.getInt("width");
        int height = json.getInt("height");

        Dungeon dungeon = new Dungeon(width, height);

        JSONArray jsonEntities = json.getJSONArray("entities");

        for (int i = 0; i < jsonEntities.length(); i++) {
            loadEntity(dungeon, jsonEntities.getJSONObject(i));
        }
        JSONObject goals = json.getJSONObject("goal-condition");
        dungeon.setGoal(loadGoal(goals, dungeon));
        return dungeon;
    }

    private Goal loadGoal(JSONObject json, Dungeon dungeon) {
        Goal newGoal = new AndGoal("AndGoal(complete all of them): ");
        boolean isAnd = true;
        String g = json.getString("goal");
        switch (g) {
            case "boulders":
                newGoal = new BoulderGoal("push all boulders onto switch", dungeon);
                break;
            case "exit":
                newGoal = new ExitGoal("reach the exit", dungeon);
                break;
            case "enemies":
                newGoal = new KillEnemyGoal("kill all the enemies", dungeon);
                break;
            case "treasure":
                newGoal = new TreasureCollectionGoal("collect all the treasures", dungeon);
                break;
            case "OR":
                newGoal = new OrGoal("OrGoal(complete one of them): ");
                isAnd = false;
                break;
        }
        if (!newGoal.isLeafGoal()) {
            JSONArray subGoals = json.getJSONArray("subgoals");
            for (int i = 0; i < subGoals.length(); i++) {
                if (isAnd) ((AndGoal)newGoal).addGoal(loadGoal( subGoals.getJSONObject(i), dungeon));
                else ((OrGoal)newGoal).addGoal(loadGoal( subGoals.getJSONObject(i), dungeon));
            }
        }
        return newGoal;
    }

    private void loadEntity(Dungeon dungeon, JSONObject json) {
        String type = json.getString("type");
        int x = json.getInt("x");
        int y = json.getInt("y");

        Entity entity = null;
        switch (type) {
        case "player":
            Player player = new Player(dungeon, new Coord(x, y));
            dungeon.setPlayer(player);
            onLoad(player);
            entity = player;
            break;
        case "wall":
            Wall wall = new Wall(new Coord(x, y), dungeon);
            onLoad(wall);
            entity = wall;
            break;
        case "exit":
        	Exit exit = new Exit(new Coord(x, y), dungeon);
        	onLoad(exit);
        	entity = exit;
        	break;
        case "boulder":
        	Boulder boulder = new Boulder(new Coord(x, y), dungeon);
        	onLoad(boulder);
        	entity = boulder;
        	break;
        case "switch":
        	Switch sw = new Switch(new Coord(x, y), dungeon);
        	onLoad(sw);
        	entity = sw;
        	break;
        case "door":
        	int id = json.getInt("id");
        	Door door = new Door(new Coord(x, y), dungeon, id);
        	onLoad(door);
        	entity = door;
        	break;
        case "key":
        	id = json.getInt("id");
            Key key = new Key(new Coord(x, y), dungeon, id);
            onLoad(key);
            entity = key;
            break;
        case "treasure":
            Treasure treasure = new Treasure(new Coord(x, y), dungeon);
            onLoad(treasure);
            entity = treasure;
            break;
        case "portal":
        	id = json.getInt("id");
        	Portal portal = new Portal(new Coord(x, y), dungeon, id);
        	onLoad(portal);
        	entity = portal;
        	break;
        case "enemy":
        	Enemy enemy = new Enemy(new Coord(x, y), dungeon);
        	dungeon.setEnemy(enemy);
        	onLoad(enemy);
        	entity = enemy;
        	break;
        case "sword":
            Sword sword = new Sword(new Coord(x, y), dungeon);
            onLoad(sword);
            entity = sword;
            break;
        case "invincibility":
            Potion potion = new Potion(new Coord(x, y), dungeon);
            onLoad(potion);
            entity = potion;
            break;
        }
        dungeon.addEntity(entity);
    }

    public abstract void onLoad(Entity player);

    public abstract void onLoad(Wall wall);

	public abstract void onLoad(Exit exit) ;

	public abstract void onLoad(Boulder boulder) ;
	
	public abstract void onLoad(Switch sw);

	public abstract void onLoad(Door door);

	public abstract void onLoad(Key key);

    public abstract void onLoad(Treasure treasure);
    
    public abstract void onLoad(Portal portal);
    
    public abstract void onLoad(Enemy enemy);

    public abstract void onLoad(Sword sword);

    public abstract void onLoad(Potion potion);
}
