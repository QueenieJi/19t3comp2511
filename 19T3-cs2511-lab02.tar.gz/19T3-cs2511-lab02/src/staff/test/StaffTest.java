package staff.test;

import staff.Lecturer;
import staff.StaffMember;

public class StaffTest {
    public void printStaffDetails(StaffMember staff) {
        String msg = staff.toString();
        System.out.println(msg);
    }

    public static void main(String[] args) {
        StaffMember staff = new StaffMember("Queenie", 10000, "2019.9.23", "2029.9.23");
        Lecturer lecturer = new Lecturer("Queenie2", 100000, "2019.9.23", "2029.9.23", "CSE", "A");
        StaffTest test = new StaffTest();
        test.printStaffDetails(staff);
        test.printStaffDetails(lecturer);
        if (staff.equals(staff)) {
            System.out.println("True");
        } else {
            System.out.println("False");
        }
        if (staff.equals(lecturer)) {
            System.out.println("True");
        } else {
            System.out.println("False");
        }
        if (lecturer.equals(lecturer)) {
            System.out.println("True");
        } else {
            System.out.println("False");
        }
    }


}

