package staff;

/**
 * A staff member
 * @author Robert Clifton-Everest
 *
 */
public class StaffMember {
    private String name = "";
    private float salary = 0;
    private String hire_date = "";
    private String end_date = "";

    public StaffMember(String name, float salary, String hire_date, String end_date) {
        this.name = name;
        this.salary = salary;
        this.hire_date = hire_date;
        this.end_date = end_date;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setSalary(float salary) {
        this.salary = salary;
    }

    public void setHireDate(String hire_date) {
        this.hire_date = hire_date;
    }

    public void setEndDate(String end_date) {
        this.end_date = end_date;
    }

    public String getName() {
        return name;
    }

    public float getSalary() {
        return salary;
    }

    public String getHireDate(){
        return hire_date;
    }

    public String getEndDate() {
        return end_date;
    }

    public String toString () {
        String msg = "Name: " + this.name + " Salary: " + this.salary + " Hire date: " + this.hire_date + " End date: " + this.end_date;
        return msg;
    }

    public boolean equals(Object obj) {
        // check it is not null
        if (obj == null) {return false;}
        // check they are in the same class
        if (this.getClass() != obj.getClass()) {
            return false;
        }
        // check the attributes
        StaffMember other = (StaffMember) obj;
        if (this.name == other.name && this.salary == other.salary && this.hire_date == other.hire_date && this.end_date == other.end_date) {
            return true;
        }
        return false;
    }
}

