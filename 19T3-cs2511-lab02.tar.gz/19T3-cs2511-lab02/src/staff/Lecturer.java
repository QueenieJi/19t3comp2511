package staff;

public class Lecturer extends StaffMember {
    private String school = "";
    private String academic_status = "";

    public Lecturer (String name, float salary, String hire_date, String end_date, String school, String academic_status) {
        super(name, salary, hire_date, end_date);
        this.school = school;
        this.academic_status = academic_status;
    }
    public String toString () {
        String msg = super.toString()+ " School: " + this.school + " Academic Level: " + this.academic_status;
        return msg;
    }

    public boolean equals(Object obj) {
        // check it is not null
        if (super.equals(obj) == false) return false;
        // check the attributes
        Lecturer other = (Lecturer) obj;
        if (this.school == other.school && this.academic_status == other.academic_status) {
            return true;
        }
        return false;
    }
}