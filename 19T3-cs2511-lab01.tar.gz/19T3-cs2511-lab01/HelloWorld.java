/**
* A simple java program that prints a hello world message to the console
*
*/
// A simple Java Program
class HelloWorld {
    public static void main(String[] args) {
       System.out.println("Hello, Welcome to merge conflicts!");
    }
}