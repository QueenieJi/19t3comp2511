package example;


/**
 * Average example
 * @author Aarthi
 */
public class Average {

        /**
         * Returns the average of an array of numbers
         * @param the array of integer numbers
         * @return the average of the numbers
         */
        public float computeAverage(int[] nums) {
            float result = 0;
            int sum = 0;
            for (int i = 0; i < nums.length; i++) {
                sum += nums[i];
            }
            result = (float)sum / nums.length;
            return result;
        }

        public static void main(String[] args) {
            int[] numbers = {1,2,3,3,4};
            Average ave = new Average();
            float re = ave.computeAverage(numbers);
            System.out.println(re);
        }
}
